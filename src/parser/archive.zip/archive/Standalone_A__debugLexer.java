// $ANTLR 3.3 Nov 30, 2010 12:45:30 C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g 2011-05-14 10:41:55

import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

public class Standalone_A__debugLexer extends Lexer {
    public static final int EOF=-1;
    public static final int STATLIST=4;
    public static final int NEWLINE=5;
    public static final int ID=6;
    public static final int ASSIGN=7;
    public static final int PLUS=8;
    public static final int MINUS=9;
    public static final int MULT=10;
    public static final int DIV=11;
    public static final int INT=12;
    public static final int DOUBLE=13;
    public static final int OPENP=14;
    public static final int CLOSEP=15;
    public static final int WS=16;
    public static final int Exponent=17;

    // delegates
    // delegators

    public Standalone_A__debugLexer() {;} 
    public Standalone_A__debugLexer(CharStream input) {
        this(input, new RecognizerSharedState());
    }
    public Standalone_A__debugLexer(CharStream input, RecognizerSharedState state) {
        super(input,state);

    }
    public String getGrammarFileName() { return "C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g"; }

    // $ANTLR start "ID"
    public final void mID() throws RecognitionException {
        try {
            int _type = ID;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:61:5: ( ( 'a' .. 'z' | 'A' .. 'Z' )+ )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:61:9: ( 'a' .. 'z' | 'A' .. 'Z' )+
            {
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:61:9: ( 'a' .. 'z' | 'A' .. 'Z' )+
            int cnt1=0;
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>='A' && LA1_0<='Z')||(LA1_0>='a' && LA1_0<='z')) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:
            	    {
            	    if ( (input.LA(1)>='A' && input.LA(1)<='Z')||(input.LA(1)>='a' && input.LA(1)<='z') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    if ( cnt1 >= 1 ) break loop1;
                        EarlyExitException eee =
                            new EarlyExitException(1, input);
                        throw eee;
                }
                cnt1++;
            } while (true);


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "ID"

    // $ANTLR start "INT"
    public final void mINT() throws RecognitionException {
        try {
            int _type = INT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:62:5: ( ( '0' .. '9' )+ )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:62:9: ( '0' .. '9' )+
            {
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:62:9: ( '0' .. '9' )+
            int cnt2=0;
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( ((LA2_0>='0' && LA2_0<='9')) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:62:9: '0' .. '9'
            	    {
            	    matchRange('0','9'); 

            	    }
            	    break;

            	default :
            	    if ( cnt2 >= 1 ) break loop2;
                        EarlyExitException eee =
                            new EarlyExitException(2, input);
                        throw eee;
                }
                cnt2++;
            } while (true);


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "INT"

    // $ANTLR start "NEWLINE"
    public final void mNEWLINE() throws RecognitionException {
        try {
            int _type = NEWLINE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:63:8: ( ( '\\r' )? '\\n' )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:63:9: ( '\\r' )? '\\n'
            {
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:63:9: ( '\\r' )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0=='\r') ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:63:9: '\\r'
                    {
                    match('\r'); 

                    }
                    break;

            }

            match('\n'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "NEWLINE"

    // $ANTLR start "WS"
    public final void mWS() throws RecognitionException {
        try {
            int _type = WS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:64:5: ( ( ' ' | '\\t' )+ )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:64:9: ( ' ' | '\\t' )+
            {
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:64:9: ( ' ' | '\\t' )+
            int cnt4=0;
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0=='\t'||LA4_0==' ') ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:
            	    {
            	    if ( input.LA(1)=='\t'||input.LA(1)==' ' ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    if ( cnt4 >= 1 ) break loop4;
                        EarlyExitException eee =
                            new EarlyExitException(4, input);
                        throw eee;
                }
                cnt4++;
            } while (true);

             _channel=HIDDEN; 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "WS"

    // $ANTLR start "MULT"
    public final void mMULT() throws RecognitionException {
        try {
            int _type = MULT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:65:5: ( '*' )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:65:7: '*'
            {
            match('*'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "MULT"

    // $ANTLR start "DIV"
    public final void mDIV() throws RecognitionException {
        try {
            int _type = DIV;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:66:4: ( '/' )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:66:6: '/'
            {
            match('/'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "DIV"

    // $ANTLR start "ASSIGN"
    public final void mASSIGN() throws RecognitionException {
        try {
            int _type = ASSIGN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:67:7: ( '=' )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:67:9: '='
            {
            match('='); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "ASSIGN"

    // $ANTLR start "PLUS"
    public final void mPLUS() throws RecognitionException {
        try {
            int _type = PLUS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:68:5: ( '+' )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:68:7: '+'
            {
            match('+'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "PLUS"

    // $ANTLR start "MINUS"
    public final void mMINUS() throws RecognitionException {
        try {
            int _type = MINUS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:69:6: ( '-' )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:69:8: '-'
            {
            match('-'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "MINUS"

    // $ANTLR start "OPENP"
    public final void mOPENP() throws RecognitionException {
        try {
            int _type = OPENP;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:70:6: ( '(' )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:70:8: '('
            {
            match('('); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "OPENP"

    // $ANTLR start "CLOSEP"
    public final void mCLOSEP() throws RecognitionException {
        try {
            int _type = CLOSEP;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:71:7: ( ')' )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:71:9: ')'
            {
            match(')'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "CLOSEP"

    // $ANTLR start "DOUBLE"
    public final void mDOUBLE() throws RecognitionException {
        try {
            int _type = DOUBLE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:72:7: ( ( '0' .. '9' )+ '.' ( '0' .. '9' )* ( Exponent )? | '.' ( '0' .. '9' )+ ( Exponent )? | ( '0' .. '9' )+ ( Exponent )? )
            int alt12=3;
            alt12 = dfa12.predict(input);
            switch (alt12) {
                case 1 :
                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:72:11: ( '0' .. '9' )+ '.' ( '0' .. '9' )* ( Exponent )?
                    {
                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:72:11: ( '0' .. '9' )+
                    int cnt5=0;
                    loop5:
                    do {
                        int alt5=2;
                        int LA5_0 = input.LA(1);

                        if ( ((LA5_0>='0' && LA5_0<='9')) ) {
                            alt5=1;
                        }


                        switch (alt5) {
                    	case 1 :
                    	    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:72:12: '0' .. '9'
                    	    {
                    	    matchRange('0','9'); 

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt5 >= 1 ) break loop5;
                                EarlyExitException eee =
                                    new EarlyExitException(5, input);
                                throw eee;
                        }
                        cnt5++;
                    } while (true);

                    match('.'); 
                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:72:27: ( '0' .. '9' )*
                    loop6:
                    do {
                        int alt6=2;
                        int LA6_0 = input.LA(1);

                        if ( ((LA6_0>='0' && LA6_0<='9')) ) {
                            alt6=1;
                        }


                        switch (alt6) {
                    	case 1 :
                    	    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:72:28: '0' .. '9'
                    	    {
                    	    matchRange('0','9'); 

                    	    }
                    	    break;

                    	default :
                    	    break loop6;
                        }
                    } while (true);

                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:72:39: ( Exponent )?
                    int alt7=2;
                    int LA7_0 = input.LA(1);

                    if ( (LA7_0=='E'||LA7_0=='e') ) {
                        alt7=1;
                    }
                    switch (alt7) {
                        case 1 :
                            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:72:39: Exponent
                            {
                            mExponent(); 

                            }
                            break;

                    }


                    }
                    break;
                case 2 :
                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:73:9: '.' ( '0' .. '9' )+ ( Exponent )?
                    {
                    match('.'); 
                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:73:13: ( '0' .. '9' )+
                    int cnt8=0;
                    loop8:
                    do {
                        int alt8=2;
                        int LA8_0 = input.LA(1);

                        if ( ((LA8_0>='0' && LA8_0<='9')) ) {
                            alt8=1;
                        }


                        switch (alt8) {
                    	case 1 :
                    	    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:73:14: '0' .. '9'
                    	    {
                    	    matchRange('0','9'); 

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt8 >= 1 ) break loop8;
                                EarlyExitException eee =
                                    new EarlyExitException(8, input);
                                throw eee;
                        }
                        cnt8++;
                    } while (true);

                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:73:25: ( Exponent )?
                    int alt9=2;
                    int LA9_0 = input.LA(1);

                    if ( (LA9_0=='E'||LA9_0=='e') ) {
                        alt9=1;
                    }
                    switch (alt9) {
                        case 1 :
                            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:73:25: Exponent
                            {
                            mExponent(); 

                            }
                            break;

                    }


                    }
                    break;
                case 3 :
                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:74:9: ( '0' .. '9' )+ ( Exponent )?
                    {
                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:74:9: ( '0' .. '9' )+
                    int cnt10=0;
                    loop10:
                    do {
                        int alt10=2;
                        int LA10_0 = input.LA(1);

                        if ( ((LA10_0>='0' && LA10_0<='9')) ) {
                            alt10=1;
                        }


                        switch (alt10) {
                    	case 1 :
                    	    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:74:10: '0' .. '9'
                    	    {
                    	    matchRange('0','9'); 

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt10 >= 1 ) break loop10;
                                EarlyExitException eee =
                                    new EarlyExitException(10, input);
                                throw eee;
                        }
                        cnt10++;
                    } while (true);

                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:74:21: ( Exponent )?
                    int alt11=2;
                    int LA11_0 = input.LA(1);

                    if ( (LA11_0=='E'||LA11_0=='e') ) {
                        alt11=1;
                    }
                    switch (alt11) {
                        case 1 :
                            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:74:21: Exponent
                            {
                            mExponent(); 

                            }
                            break;

                    }


                    }
                    break;

            }
            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "DOUBLE"

    // $ANTLR start "Exponent"
    public final void mExponent() throws RecognitionException {
        try {
            int _type = Exponent;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:76:10: ( ( 'e' | 'E' ) ( '+' | '-' )? ( '0' .. '9' )+ )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:76:12: ( 'e' | 'E' ) ( '+' | '-' )? ( '0' .. '9' )+
            {
            if ( input.LA(1)=='E'||input.LA(1)=='e' ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}

            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:76:22: ( '+' | '-' )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0=='+'||LA13_0=='-') ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:
                    {
                    if ( input.LA(1)=='+'||input.LA(1)=='-' ) {
                        input.consume();

                    }
                    else {
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        recover(mse);
                        throw mse;}


                    }
                    break;

            }

            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:76:33: ( '0' .. '9' )+
            int cnt14=0;
            loop14:
            do {
                int alt14=2;
                int LA14_0 = input.LA(1);

                if ( ((LA14_0>='0' && LA14_0<='9')) ) {
                    alt14=1;
                }


                switch (alt14) {
            	case 1 :
            	    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:76:34: '0' .. '9'
            	    {
            	    matchRange('0','9'); 

            	    }
            	    break;

            	default :
            	    if ( cnt14 >= 1 ) break loop14;
                        EarlyExitException eee =
                            new EarlyExitException(14, input);
                        throw eee;
                }
                cnt14++;
            } while (true);


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "Exponent"

    public void mTokens() throws RecognitionException {
        // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:1:8: ( ID | INT | NEWLINE | WS | MULT | DIV | ASSIGN | PLUS | MINUS | OPENP | CLOSEP | DOUBLE | Exponent )
        int alt15=13;
        alt15 = dfa15.predict(input);
        switch (alt15) {
            case 1 :
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:1:10: ID
                {
                mID(); 

                }
                break;
            case 2 :
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:1:13: INT
                {
                mINT(); 

                }
                break;
            case 3 :
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:1:17: NEWLINE
                {
                mNEWLINE(); 

                }
                break;
            case 4 :
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:1:25: WS
                {
                mWS(); 

                }
                break;
            case 5 :
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:1:28: MULT
                {
                mMULT(); 

                }
                break;
            case 6 :
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:1:33: DIV
                {
                mDIV(); 

                }
                break;
            case 7 :
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:1:37: ASSIGN
                {
                mASSIGN(); 

                }
                break;
            case 8 :
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:1:44: PLUS
                {
                mPLUS(); 

                }
                break;
            case 9 :
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:1:49: MINUS
                {
                mMINUS(); 

                }
                break;
            case 10 :
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:1:55: OPENP
                {
                mOPENP(); 

                }
                break;
            case 11 :
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:1:61: CLOSEP
                {
                mCLOSEP(); 

                }
                break;
            case 12 :
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:1:68: DOUBLE
                {
                mDOUBLE(); 

                }
                break;
            case 13 :
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:1:75: Exponent
                {
                mExponent(); 

                }
                break;

        }

    }


    protected DFA12 dfa12 = new DFA12(this);
    protected DFA15 dfa15 = new DFA15(this);
    static final String DFA12_eotS =
        "\1\uffff\1\4\3\uffff";
    static final String DFA12_eofS =
        "\5\uffff";
    static final String DFA12_minS =
        "\2\56\3\uffff";
    static final String DFA12_maxS =
        "\2\71\3\uffff";
    static final String DFA12_acceptS =
        "\2\uffff\1\2\1\1\1\3";
    static final String DFA12_specialS =
        "\5\uffff}>";
    static final String[] DFA12_transitionS = {
            "\1\2\1\uffff\12\1",
            "\1\3\1\uffff\12\1",
            "",
            "",
            ""
    };

    static final short[] DFA12_eot = DFA.unpackEncodedString(DFA12_eotS);
    static final short[] DFA12_eof = DFA.unpackEncodedString(DFA12_eofS);
    static final char[] DFA12_min = DFA.unpackEncodedStringToUnsignedChars(DFA12_minS);
    static final char[] DFA12_max = DFA.unpackEncodedStringToUnsignedChars(DFA12_maxS);
    static final short[] DFA12_accept = DFA.unpackEncodedString(DFA12_acceptS);
    static final short[] DFA12_special = DFA.unpackEncodedString(DFA12_specialS);
    static final short[][] DFA12_transition;

    static {
        int numStates = DFA12_transitionS.length;
        DFA12_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA12_transition[i] = DFA.unpackEncodedString(DFA12_transitionS[i]);
        }
    }

    class DFA12 extends DFA {

        public DFA12(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 12;
            this.eot = DFA12_eot;
            this.eof = DFA12_eof;
            this.min = DFA12_min;
            this.max = DFA12_max;
            this.accept = DFA12_accept;
            this.special = DFA12_special;
            this.transition = DFA12_transition;
        }
        public String getDescription() {
            return "72:1: DOUBLE : ( ( '0' .. '9' )+ '.' ( '0' .. '9' )* ( Exponent )? | '.' ( '0' .. '9' )+ ( Exponent )? | ( '0' .. '9' )+ ( Exponent )? );";
        }
    }
    static final String DFA15_eotS =
        "\1\uffff\1\15\1\17\15\uffff";
    static final String DFA15_eofS =
        "\20\uffff";
    static final String DFA15_minS =
        "\1\11\1\53\1\56\15\uffff";
    static final String DFA15_maxS =
        "\1\172\1\71\1\145\15\uffff";
    static final String DFA15_acceptS =
        "\3\uffff\1\3\1\4\1\5\1\6\1\7\1\10\1\11\1\12\1\13\1\14\1\1\1\15"+
        "\1\2";
    static final String DFA15_specialS =
        "\20\uffff}>";
    static final String[] DFA15_transitionS = {
            "\1\4\1\3\2\uffff\1\3\22\uffff\1\4\7\uffff\1\12\1\13\1\5\1\10"+
            "\1\uffff\1\11\1\14\1\6\12\2\3\uffff\1\7\3\uffff\4\15\1\1\25"+
            "\15\6\uffff\4\15\1\1\25\15",
            "\1\16\1\uffff\1\16\2\uffff\12\16",
            "\1\14\1\uffff\12\2\13\uffff\1\14\37\uffff\1\14",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA15_eot = DFA.unpackEncodedString(DFA15_eotS);
    static final short[] DFA15_eof = DFA.unpackEncodedString(DFA15_eofS);
    static final char[] DFA15_min = DFA.unpackEncodedStringToUnsignedChars(DFA15_minS);
    static final char[] DFA15_max = DFA.unpackEncodedStringToUnsignedChars(DFA15_maxS);
    static final short[] DFA15_accept = DFA.unpackEncodedString(DFA15_acceptS);
    static final short[] DFA15_special = DFA.unpackEncodedString(DFA15_specialS);
    static final short[][] DFA15_transition;

    static {
        int numStates = DFA15_transitionS.length;
        DFA15_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA15_transition[i] = DFA.unpackEncodedString(DFA15_transitionS[i]);
        }
    }

    class DFA15 extends DFA {

        public DFA15(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 15;
            this.eot = DFA15_eot;
            this.eof = DFA15_eof;
            this.min = DFA15_min;
            this.max = DFA15_max;
            this.accept = DFA15_accept;
            this.special = DFA15_special;
            this.transition = DFA15_transition;
        }
        public String getDescription() {
            return "1:1: Tokens : ( ID | INT | NEWLINE | WS | MULT | DIV | ASSIGN | PLUS | MINUS | OPENP | CLOSEP | DOUBLE | Exponent );";
        }
    }
 

}