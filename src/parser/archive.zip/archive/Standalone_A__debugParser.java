// $ANTLR 3.3 Nov 30, 2010 12:45:30 C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g 2011-05-14 10:41:54

import java.util.HashMap; 


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

import org.antlr.runtime.debug.*;
import java.io.IOException;

import org.antlr.runtime.tree.*;

public class Standalone_A__debugParser extends DebugParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "STATLIST", "NEWLINE", "ID", "ASSIGN", "PLUS", "MINUS", "MULT", "DIV", "INT", "DOUBLE", "OPENP", "CLOSEP", "WS", "Exponent"
    };
    public static final int EOF=-1;
    public static final int STATLIST=4;
    public static final int NEWLINE=5;
    public static final int ID=6;
    public static final int ASSIGN=7;
    public static final int PLUS=8;
    public static final int MINUS=9;
    public static final int MULT=10;
    public static final int DIV=11;
    public static final int INT=12;
    public static final int DOUBLE=13;
    public static final int OPENP=14;
    public static final int CLOSEP=15;
    public static final int WS=16;
    public static final int Exponent=17;

    // delegates
    // delegators

    public static final String[] ruleNames = new String[] {
        "invalidRule", "stat", "prog", "expr", "multExpr", "atom"
    };
    public static final boolean[] decisionCanBacktrack = new boolean[] {
        false, // invalid decision
        false, false, false, false, false, false
    };

     
        public int ruleLevel = 0;
        public int getRuleLevel() { return ruleLevel; }
        public void incRuleLevel() { ruleLevel++; }
        public void decRuleLevel() { ruleLevel--; }
        public Standalone_A__debugParser(TokenStream input) {
            this(input, DebugEventSocketProxy.DEFAULT_DEBUGGER_PORT, new RecognizerSharedState());
        }
        public Standalone_A__debugParser(TokenStream input, int port, RecognizerSharedState state) {
            super(input, state);
            DebugEventSocketProxy proxy =
                new DebugEventSocketProxy(this,port,adaptor);
            setDebugListener(proxy);
            setTokenStream(new DebugTokenStream(input,proxy));
            try {
                proxy.handshake();
            }
            catch (IOException ioe) {
                reportError(ioe);
            }
            TreeAdaptor adap = new CommonTreeAdaptor();
            setTreeAdaptor(adap);
            proxy.setTreeAdaptor(adap);
        }
    public Standalone_A__debugParser(TokenStream input, DebugEventListener dbg) {
        super(input, dbg);

         
        TreeAdaptor adap = new CommonTreeAdaptor();
        setTreeAdaptor(adap);

    }
    protected boolean evalPredicate(boolean result, String predicate) {
        dbg.semanticPredicate(result, predicate);
        return result;
    }

    protected DebugTreeAdaptor adaptor;
    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = new DebugTreeAdaptor(dbg,adaptor);

    }
    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }


    public String[] getTokenNames() { return Standalone_A__debugParser.tokenNames; }
    public String getGrammarFileName() { return "C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g"; }


    HashMap memory = new HashMap();


    public static class prog_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "prog"
    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:19:1: prog : ( stat )+ -> ^( STATLIST ( stat )+ ) ;
    public final Standalone_A__debugParser.prog_return prog() throws RecognitionException {
        Standalone_A__debugParser.prog_return retval = new Standalone_A__debugParser.prog_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Standalone_A__debugParser.stat_return stat1 = null;


        RewriteRuleSubtreeStream stream_stat=new RewriteRuleSubtreeStream(adaptor,"rule stat");
        try { dbg.enterRule(getGrammarFileName(), "prog");
        if ( getRuleLevel()==0 ) {dbg.commence();}
        incRuleLevel();
        dbg.location(19, 1);

        try {
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:19:5: ( ( stat )+ -> ^( STATLIST ( stat )+ ) )
            dbg.enterAlt(1);

            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:19:9: ( stat )+
            {
            dbg.location(19,9);
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:19:9: ( stat )+
            int cnt1=0;
            try { dbg.enterSubRule(1);

            loop1:
            do {
                int alt1=2;
                try { dbg.enterDecision(1, decisionCanBacktrack[1]);

                int LA1_0 = input.LA(1);

                if ( ((LA1_0>=NEWLINE && LA1_0<=ID)||(LA1_0>=INT && LA1_0<=OPENP)) ) {
                    alt1=1;
                }


                } finally {dbg.exitDecision(1);}

                switch (alt1) {
            	case 1 :
            	    dbg.enterAlt(1);

            	    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:19:11: stat
            	    {
            	    dbg.location(19,11);
            	    pushFollow(FOLLOW_stat_in_prog57);
            	    stat1=stat();

            	    state._fsp--;

            	    stream_stat.add(stat1.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt1 >= 1 ) break loop1;
                        EarlyExitException eee =
                            new EarlyExitException(1, input);
                        dbg.recognitionException(eee);

                        throw eee;
                }
                cnt1++;
            } while (true);
            } finally {dbg.exitSubRule(1);}



            // AST REWRITE
            // elements: stat
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 19:19: -> ^( STATLIST ( stat )+ )
            {
                dbg.location(19,22);
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:19:22: ^( STATLIST ( stat )+ )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                dbg.location(19,24);
                root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(STATLIST, "STATLIST"), root_1);

                dbg.location(19,33);
                if ( !(stream_stat.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_stat.hasNext() ) {
                    dbg.location(19,34);
                    adaptor.addChild(root_1, stream_stat.nextTree());

                }
                stream_stat.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        dbg.location(19, 42);

        }
        finally {
            dbg.exitRule(getGrammarFileName(), "prog");
            decRuleLevel();
            if ( getRuleLevel()==0 ) {dbg.terminate();}
        }

        return retval;
    }
    // $ANTLR end "prog"

    public static class stat_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "stat"
    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:21:1: stat : ( expr NEWLINE | ID ASSIGN expr NEWLINE | NEWLINE );
    public final Standalone_A__debugParser.stat_return stat() throws RecognitionException {
        Standalone_A__debugParser.stat_return retval = new Standalone_A__debugParser.stat_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token NEWLINE3=null;
        Token ID4=null;
        Token ASSIGN5=null;
        Token NEWLINE7=null;
        Token NEWLINE8=null;
        Standalone_A__debugParser.expr_return expr2 = null;

        Standalone_A__debugParser.expr_return expr6 = null;


        CommonTree NEWLINE3_tree=null;
        CommonTree ID4_tree=null;
        CommonTree ASSIGN5_tree=null;
        CommonTree NEWLINE7_tree=null;
        CommonTree NEWLINE8_tree=null;

        try { dbg.enterRule(getGrammarFileName(), "stat");
        if ( getRuleLevel()==0 ) {dbg.commence();}
        incRuleLevel();
        dbg.location(21, 1);

        try {
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:21:5: ( expr NEWLINE | ID ASSIGN expr NEWLINE | NEWLINE )
            int alt2=3;
            try { dbg.enterDecision(2, decisionCanBacktrack[2]);

            switch ( input.LA(1) ) {
            case INT:
            case DOUBLE:
            case OPENP:
                {
                alt2=1;
                }
                break;
            case ID:
                {
                int LA2_2 = input.LA(2);

                if ( (LA2_2==NEWLINE||(LA2_2>=PLUS && LA2_2<=DIV)||LA2_2==OPENP) ) {
                    alt2=1;
                }
                else if ( (LA2_2==ASSIGN) ) {
                    alt2=2;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 2, 2, input);

                    dbg.recognitionException(nvae);
                    throw nvae;
                }
                }
                break;
            case NEWLINE:
                {
                alt2=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                dbg.recognitionException(nvae);
                throw nvae;
            }

            } finally {dbg.exitDecision(2);}

            switch (alt2) {
                case 1 :
                    dbg.enterAlt(1);

                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:21:9: expr NEWLINE
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    dbg.location(21,9);
                    pushFollow(FOLLOW_expr_in_stat81);
                    expr2=expr();

                    state._fsp--;

                    adaptor.addChild(root_0, expr2.getTree());
                    dbg.location(21,14);
                    NEWLINE3=(Token)match(input,NEWLINE,FOLLOW_NEWLINE_in_stat83); 
                    NEWLINE3_tree = (CommonTree)adaptor.create(NEWLINE3);
                    adaptor.addChild(root_0, NEWLINE3_tree);

                    dbg.location(21,23);
                     System.out.println("ans = " + (expr2!=null?expr2.value:0.0)); 
                    			memory.put("ans", new Double((expr2!=null?expr2.value:0.0))); 
                    		

                    }
                    break;
                case 2 :
                    dbg.enterAlt(2);

                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:24:9: ID ASSIGN expr NEWLINE
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    dbg.location(24,9);
                    ID4=(Token)match(input,ID,FOLLOW_ID_in_stat96); 
                    ID4_tree = (CommonTree)adaptor.create(ID4);
                    adaptor.addChild(root_0, ID4_tree);

                    dbg.location(24,12);
                    ASSIGN5=(Token)match(input,ASSIGN,FOLLOW_ASSIGN_in_stat98); 
                    ASSIGN5_tree = (CommonTree)adaptor.create(ASSIGN5);
                    adaptor.addChild(root_0, ASSIGN5_tree);

                    dbg.location(24,19);
                    pushFollow(FOLLOW_expr_in_stat100);
                    expr6=expr();

                    state._fsp--;

                    adaptor.addChild(root_0, expr6.getTree());
                    dbg.location(24,25);
                    NEWLINE7=(Token)match(input,NEWLINE,FOLLOW_NEWLINE_in_stat103); 
                    NEWLINE7_tree = (CommonTree)adaptor.create(NEWLINE7);
                    adaptor.addChild(root_0, NEWLINE7_tree);

                    dbg.location(24,33);
                    memory.put( (ID4!=null?ID4.getText():null), new Double((expr6!=null?expr6.value:0.0)));
                                                     System.out.println((ID4!=null?ID4.getText():null) + " = " + (expr6!=null?expr6.value:0.0)); 

                    }
                    break;
                case 3 :
                    dbg.enterAlt(3);

                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:26:9: NEWLINE
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    dbg.location(26,9);
                    NEWLINE8=(Token)match(input,NEWLINE,FOLLOW_NEWLINE_in_stat115); 
                    NEWLINE8_tree = (CommonTree)adaptor.create(NEWLINE8);
                    adaptor.addChild(root_0, NEWLINE8_tree);


                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        dbg.location(27, 5);

        }
        finally {
            dbg.exitRule(getGrammarFileName(), "stat");
            decRuleLevel();
            if ( getRuleLevel()==0 ) {dbg.terminate();}
        }

        return retval;
    }
    // $ANTLR end "stat"

    public static class expr_return extends ParserRuleReturnScope {
        public double value;
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "expr"
    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:29:1: expr returns [double value] : e= multExpr ( PLUS e= multExpr | MINUS e= multExpr )* ;
    public final Standalone_A__debugParser.expr_return expr() throws RecognitionException {
        Standalone_A__debugParser.expr_return retval = new Standalone_A__debugParser.expr_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token PLUS9=null;
        Token MINUS10=null;
        Standalone_A__debugParser.multExpr_return e = null;


        CommonTree PLUS9_tree=null;
        CommonTree MINUS10_tree=null;

        try { dbg.enterRule(getGrammarFileName(), "expr");
        if ( getRuleLevel()==0 ) {dbg.commence();}
        incRuleLevel();
        dbg.location(29, 1);

        try {
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:30:2: (e= multExpr ( PLUS e= multExpr | MINUS e= multExpr )* )
            dbg.enterAlt(1);

            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:30:4: e= multExpr ( PLUS e= multExpr | MINUS e= multExpr )*
            {
            root_0 = (CommonTree)adaptor.nil();

            dbg.location(30,5);
            pushFollow(FOLLOW_multExpr_in_expr138);
            e=multExpr();

            state._fsp--;

            adaptor.addChild(root_0, e.getTree());
            dbg.location(30,15);
            retval.value = (e!=null?e.value:0.0);
            dbg.location(31,3);
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:31:3: ( PLUS e= multExpr | MINUS e= multExpr )*
            try { dbg.enterSubRule(3);

            loop3:
            do {
                int alt3=3;
                try { dbg.enterDecision(3, decisionCanBacktrack[3]);

                int LA3_0 = input.LA(1);

                if ( (LA3_0==PLUS) ) {
                    alt3=1;
                }
                else if ( (LA3_0==MINUS) ) {
                    alt3=2;
                }


                } finally {dbg.exitDecision(3);}

                switch (alt3) {
            	case 1 :
            	    dbg.enterAlt(1);

            	    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:31:5: PLUS e= multExpr
            	    {
            	    dbg.location(31,5);
            	    PLUS9=(Token)match(input,PLUS,FOLLOW_PLUS_in_expr146); 
            	    PLUS9_tree = (CommonTree)adaptor.create(PLUS9);
            	    adaptor.addChild(root_0, PLUS9_tree);

            	    dbg.location(31,11);
            	    pushFollow(FOLLOW_multExpr_in_expr150);
            	    e=multExpr();

            	    state._fsp--;

            	    adaptor.addChild(root_0, e.getTree());
            	    dbg.location(31,21);
            	    retval.value += (e!=null?e.value:0.0);

            	    }
            	    break;
            	case 2 :
            	    dbg.enterAlt(2);

            	    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:32:5: MINUS e= multExpr
            	    {
            	    dbg.location(32,5);
            	    MINUS10=(Token)match(input,MINUS,FOLLOW_MINUS_in_expr158); 
            	    MINUS10_tree = (CommonTree)adaptor.create(MINUS10);
            	    adaptor.addChild(root_0, MINUS10_tree);

            	    dbg.location(32,12);
            	    pushFollow(FOLLOW_multExpr_in_expr162);
            	    e=multExpr();

            	    state._fsp--;

            	    adaptor.addChild(root_0, e.getTree());
            	    dbg.location(32,22);
            	    retval.value -= (e!=null?e.value:0.0);

            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);
            } finally {dbg.exitSubRule(3);}


            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        dbg.location(34, 5);

        }
        finally {
            dbg.exitRule(getGrammarFileName(), "expr");
            decRuleLevel();
            if ( getRuleLevel()==0 ) {dbg.terminate();}
        }

        return retval;
    }
    // $ANTLR end "expr"

    public static class multExpr_return extends ParserRuleReturnScope {
        public double value;
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "multExpr"
    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:36:1: multExpr returns [double value] : e= atom ( MULT e= atom )* ( DIV e= atom )* ;
    public final Standalone_A__debugParser.multExpr_return multExpr() throws RecognitionException {
        Standalone_A__debugParser.multExpr_return retval = new Standalone_A__debugParser.multExpr_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token MULT11=null;
        Token DIV12=null;
        Standalone_A__debugParser.atom_return e = null;


        CommonTree MULT11_tree=null;
        CommonTree DIV12_tree=null;

        try { dbg.enterRule(getGrammarFileName(), "multExpr");
        if ( getRuleLevel()==0 ) {dbg.commence();}
        incRuleLevel();
        dbg.location(36, 1);

        try {
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:37:5: (e= atom ( MULT e= atom )* ( DIV e= atom )* )
            dbg.enterAlt(1);

            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:37:9: e= atom ( MULT e= atom )* ( DIV e= atom )*
            {
            root_0 = (CommonTree)adaptor.nil();

            dbg.location(37,10);
            pushFollow(FOLLOW_atom_in_multExpr195);
            e=atom();

            state._fsp--;

            adaptor.addChild(root_0, e.getTree());
            dbg.location(37,15);
            retval.value = (e!=null?e.value:0.0);
            dbg.location(38,9);
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:38:9: ( MULT e= atom )*
            try { dbg.enterSubRule(4);

            loop4:
            do {
                int alt4=2;
                try { dbg.enterDecision(4, decisionCanBacktrack[4]);

                int LA4_0 = input.LA(1);

                if ( (LA4_0==MULT) ) {
                    alt4=1;
                }


                } finally {dbg.exitDecision(4);}

                switch (alt4) {
            	case 1 :
            	    dbg.enterAlt(1);

            	    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:38:10: MULT e= atom
            	    {
            	    dbg.location(38,10);
            	    MULT11=(Token)match(input,MULT,FOLLOW_MULT_in_multExpr208); 
            	    MULT11_tree = (CommonTree)adaptor.create(MULT11);
            	    adaptor.addChild(root_0, MULT11_tree);

            	    dbg.location(38,16);
            	    pushFollow(FOLLOW_atom_in_multExpr212);
            	    e=atom();

            	    state._fsp--;

            	    adaptor.addChild(root_0, e.getTree());
            	    dbg.location(38,21);
            	    retval.value *= (e!=null?e.value:0.0); 

            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);
            } finally {dbg.exitSubRule(4);}

            dbg.location(39,9);
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:39:9: ( DIV e= atom )*
            try { dbg.enterSubRule(5);

            loop5:
            do {
                int alt5=2;
                try { dbg.enterDecision(5, decisionCanBacktrack[5]);

                int LA5_0 = input.LA(1);

                if ( (LA5_0==DIV) ) {
                    alt5=1;
                }


                } finally {dbg.exitDecision(5);}

                switch (alt5) {
            	case 1 :
            	    dbg.enterAlt(1);

            	    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:39:10: DIV e= atom
            	    {
            	    dbg.location(39,10);
            	    DIV12=(Token)match(input,DIV,FOLLOW_DIV_in_multExpr229); 
            	    DIV12_tree = (CommonTree)adaptor.create(DIV12);
            	    adaptor.addChild(root_0, DIV12_tree);

            	    dbg.location(39,15);
            	    pushFollow(FOLLOW_atom_in_multExpr233);
            	    e=atom();

            	    state._fsp--;

            	    adaptor.addChild(root_0, e.getTree());
            	    dbg.location(39,20);
            	    retval.value /= (e!=null?e.value:0.0); 

            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);
            } finally {dbg.exitSubRule(5);}


            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        dbg.location(40, 5);

        }
        finally {
            dbg.exitRule(getGrammarFileName(), "multExpr");
            decRuleLevel();
            if ( getRuleLevel()==0 ) {dbg.terminate();}
        }

        return retval;
    }
    // $ANTLR end "multExpr"

    public static class atom_return extends ParserRuleReturnScope {
        public double value;
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "atom"
    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:43:1: atom returns [double value] : ( INT | DOUBLE | ID | '(' expr ')' | ID OPENP expr CLOSEP );
    public final Standalone_A__debugParser.atom_return atom() throws RecognitionException {
        Standalone_A__debugParser.atom_return retval = new Standalone_A__debugParser.atom_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token INT13=null;
        Token DOUBLE14=null;
        Token ID15=null;
        Token char_literal16=null;
        Token char_literal18=null;
        Token ID19=null;
        Token OPENP20=null;
        Token CLOSEP22=null;
        Standalone_A__debugParser.expr_return expr17 = null;

        Standalone_A__debugParser.expr_return expr21 = null;


        CommonTree INT13_tree=null;
        CommonTree DOUBLE14_tree=null;
        CommonTree ID15_tree=null;
        CommonTree char_literal16_tree=null;
        CommonTree char_literal18_tree=null;
        CommonTree ID19_tree=null;
        CommonTree OPENP20_tree=null;
        CommonTree CLOSEP22_tree=null;

        try { dbg.enterRule(getGrammarFileName(), "atom");
        if ( getRuleLevel()==0 ) {dbg.commence();}
        incRuleLevel();
        dbg.location(43, 1);

        try {
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:44:2: ( INT | DOUBLE | ID | '(' expr ')' | ID OPENP expr CLOSEP )
            int alt6=5;
            try { dbg.enterDecision(6, decisionCanBacktrack[6]);

            switch ( input.LA(1) ) {
            case INT:
                {
                alt6=1;
                }
                break;
            case DOUBLE:
                {
                alt6=2;
                }
                break;
            case ID:
                {
                int LA6_3 = input.LA(2);

                if ( (LA6_3==OPENP) ) {
                    alt6=5;
                }
                else if ( (LA6_3==NEWLINE||(LA6_3>=PLUS && LA6_3<=DIV)||LA6_3==CLOSEP) ) {
                    alt6=3;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 6, 3, input);

                    dbg.recognitionException(nvae);
                    throw nvae;
                }
                }
                break;
            case OPENP:
                {
                alt6=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                dbg.recognitionException(nvae);
                throw nvae;
            }

            } finally {dbg.exitDecision(6);}

            switch (alt6) {
                case 1 :
                    dbg.enterAlt(1);

                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:44:6: INT
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    dbg.location(44,6);
                    INT13=(Token)match(input,INT,FOLLOW_INT_in_atom269); 
                    INT13_tree = (CommonTree)adaptor.create(INT13);
                    adaptor.addChild(root_0, INT13_tree);

                    dbg.location(44,10);
                    retval.value = Double.parseDouble((INT13!=null?INT13.getText():null));

                    }
                    break;
                case 2 :
                    dbg.enterAlt(2);

                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:45:6: DOUBLE
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    dbg.location(45,6);
                    DOUBLE14=(Token)match(input,DOUBLE,FOLLOW_DOUBLE_in_atom278); 
                    DOUBLE14_tree = (CommonTree)adaptor.create(DOUBLE14);
                    adaptor.addChild(root_0, DOUBLE14_tree);

                    dbg.location(45,13);
                    retval.value = Double.parseDouble((DOUBLE14!=null?DOUBLE14.getText():null));

                    }
                    break;
                case 3 :
                    dbg.enterAlt(3);

                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:46:10: ID
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    dbg.location(46,10);
                    ID15=(Token)match(input,ID,FOLLOW_ID_in_atom291); 
                    ID15_tree = (CommonTree)adaptor.create(ID15);
                    adaptor.addChild(root_0, ID15_tree);

                    dbg.location(46,13);

                                 Double v = (Double) memory.get((ID15!=null?ID15.getText():null));
                                 if(v == null) {
                                     System.err.println("undefined variable " + (ID15!=null?ID15.getText():null));
                                     retval.value = -1;
                                 } else {
                                 	retval.value = v.doubleValue();
                                 }

                    }
                    break;
                case 4 :
                    dbg.enterAlt(4);

                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:54:9: '(' expr ')'
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    dbg.location(54,12);
                    char_literal16=(Token)match(input,OPENP,FOLLOW_OPENP_in_atom303); 
                    dbg.location(54,14);
                    pushFollow(FOLLOW_expr_in_atom306);
                    expr17=expr();

                    state._fsp--;

                    adaptor.addChild(root_0, expr17.getTree());
                    dbg.location(54,22);
                    char_literal18=(Token)match(input,CLOSEP,FOLLOW_CLOSEP_in_atom308); 
                    dbg.location(54,24);
                    retval.value = (expr17!=null?expr17.value:0.0);

                    }
                    break;
                case 5 :
                    dbg.enterAlt(5);

                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A__debug.g:55:7: ID OPENP expr CLOSEP
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    dbg.location(55,7);
                    ID19=(Token)match(input,ID,FOLLOW_ID_in_atom319); 
                    ID19_tree = (CommonTree)adaptor.create(ID19);
                    adaptor.addChild(root_0, ID19_tree);

                    dbg.location(55,10);
                    OPENP20=(Token)match(input,OPENP,FOLLOW_OPENP_in_atom321); 
                    OPENP20_tree = (CommonTree)adaptor.create(OPENP20);
                    adaptor.addChild(root_0, OPENP20_tree);

                    dbg.location(55,16);
                    pushFollow(FOLLOW_expr_in_atom323);
                    expr21=expr();

                    state._fsp--;

                    adaptor.addChild(root_0, expr21.getTree());
                    dbg.location(55,21);
                    CLOSEP22=(Token)match(input,CLOSEP,FOLLOW_CLOSEP_in_atom325); 
                    CLOSEP22_tree = (CommonTree)adaptor.create(CLOSEP22);
                    adaptor.addChild(root_0, CLOSEP22_tree);

                    dbg.location(55,28);

                                 retval.value = 0;
                                 System.out.println("call( " + (ID19!=null?ID19.getText():null) + ", " + (expr21!=null?expr21.value:0.0) + ")");
                             

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        dbg.location(59, 5);

        }
        finally {
            dbg.exitRule(getGrammarFileName(), "atom");
            decRuleLevel();
            if ( getRuleLevel()==0 ) {dbg.terminate();}
        }

        return retval;
    }
    // $ANTLR end "atom"

    // Delegated rules


 

    public static final BitSet FOLLOW_stat_in_prog57 = new BitSet(new long[]{0x0000000000007062L});
    public static final BitSet FOLLOW_expr_in_stat81 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_NEWLINE_in_stat83 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_stat96 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_ASSIGN_in_stat98 = new BitSet(new long[]{0x0000000000007040L});
    public static final BitSet FOLLOW_expr_in_stat100 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_NEWLINE_in_stat103 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NEWLINE_in_stat115 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_multExpr_in_expr138 = new BitSet(new long[]{0x0000000000000302L});
    public static final BitSet FOLLOW_PLUS_in_expr146 = new BitSet(new long[]{0x0000000000007040L});
    public static final BitSet FOLLOW_multExpr_in_expr150 = new BitSet(new long[]{0x0000000000000302L});
    public static final BitSet FOLLOW_MINUS_in_expr158 = new BitSet(new long[]{0x0000000000007040L});
    public static final BitSet FOLLOW_multExpr_in_expr162 = new BitSet(new long[]{0x0000000000000302L});
    public static final BitSet FOLLOW_atom_in_multExpr195 = new BitSet(new long[]{0x0000000000000C02L});
    public static final BitSet FOLLOW_MULT_in_multExpr208 = new BitSet(new long[]{0x0000000000007040L});
    public static final BitSet FOLLOW_atom_in_multExpr212 = new BitSet(new long[]{0x0000000000000C02L});
    public static final BitSet FOLLOW_DIV_in_multExpr229 = new BitSet(new long[]{0x0000000000007040L});
    public static final BitSet FOLLOW_atom_in_multExpr233 = new BitSet(new long[]{0x0000000000000802L});
    public static final BitSet FOLLOW_INT_in_atom269 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DOUBLE_in_atom278 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_atom291 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_OPENP_in_atom303 = new BitSet(new long[]{0x0000000000007040L});
    public static final BitSet FOLLOW_expr_in_atom306 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_CLOSEP_in_atom308 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_atom319 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_OPENP_in_atom321 = new BitSet(new long[]{0x0000000000007040L});
    public static final BitSet FOLLOW_expr_in_atom323 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_CLOSEP_in_atom325 = new BitSet(new long[]{0x0000000000000002L});

}