// $ANTLR 3.3 Nov 30, 2010 12:45:30 C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g 2011-05-16 13:49:42

package parser;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

public class withColonLexer extends Lexer {
    public static final int EOF=-1;
    public static final int STATLIST=4;
    public static final int NEWLINE=5;
    public static final int ID=6;
    public static final int ASSIGN=7;
    public static final int PLUS=8;
    public static final int MINUS=9;
    public static final int MULT=10;
    public static final int DIV=11;
    public static final int DOUBLE=12;
    public static final int OPENP=13;
    public static final int CLOSEP=14;
    public static final int OPENB=15;
    public static final int CLOSEB=16;
    public static final int COMMA=17;
    public static final int COLON=18;
    public static final int WS=19;
    public static final int Exponent=20;

    // delegates
    // delegators

    public withColonLexer() {;} 
    public withColonLexer(CharStream input) {
        this(input, new RecognizerSharedState());
    }
    public withColonLexer(CharStream input, RecognizerSharedState state) {
        super(input,state);

    }
    public String getGrammarFileName() { return "C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g"; }

    // $ANTLR start "ID"
    public final void mID() throws RecognitionException {
        try {
            int _type = ID;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:90:5: ( ( 'a' .. 'z' | 'A' .. 'Z' )+ )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:90:9: ( 'a' .. 'z' | 'A' .. 'Z' )+
            {
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:90:9: ( 'a' .. 'z' | 'A' .. 'Z' )+
            int cnt1=0;
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>='A' && LA1_0<='Z')||(LA1_0>='a' && LA1_0<='z')) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:
            	    {
            	    if ( (input.LA(1)>='A' && input.LA(1)<='Z')||(input.LA(1)>='a' && input.LA(1)<='z') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    if ( cnt1 >= 1 ) break loop1;
                        EarlyExitException eee =
                            new EarlyExitException(1, input);
                        throw eee;
                }
                cnt1++;
            } while (true);


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "ID"

    // $ANTLR start "NEWLINE"
    public final void mNEWLINE() throws RecognitionException {
        try {
            int _type = NEWLINE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:91:8: ( ( '\\r' )? '\\n' )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:91:9: ( '\\r' )? '\\n'
            {
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:91:9: ( '\\r' )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0=='\r') ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:91:9: '\\r'
                    {
                    match('\r'); 

                    }
                    break;

            }

            match('\n'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "NEWLINE"

    // $ANTLR start "WS"
    public final void mWS() throws RecognitionException {
        try {
            int _type = WS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:92:5: ( ( ' ' | '\\t' )+ )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:92:9: ( ' ' | '\\t' )+
            {
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:92:9: ( ' ' | '\\t' )+
            int cnt3=0;
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0=='\t'||LA3_0==' ') ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:
            	    {
            	    if ( input.LA(1)=='\t'||input.LA(1)==' ' ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    if ( cnt3 >= 1 ) break loop3;
                        EarlyExitException eee =
                            new EarlyExitException(3, input);
                        throw eee;
                }
                cnt3++;
            } while (true);

             _channel=HIDDEN; 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "WS"

    // $ANTLR start "MULT"
    public final void mMULT() throws RecognitionException {
        try {
            int _type = MULT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:93:5: ( '*' )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:93:7: '*'
            {
            match('*'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "MULT"

    // $ANTLR start "DIV"
    public final void mDIV() throws RecognitionException {
        try {
            int _type = DIV;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:94:4: ( '/' )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:94:6: '/'
            {
            match('/'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "DIV"

    // $ANTLR start "ASSIGN"
    public final void mASSIGN() throws RecognitionException {
        try {
            int _type = ASSIGN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:95:7: ( '=' )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:95:9: '='
            {
            match('='); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "ASSIGN"

    // $ANTLR start "PLUS"
    public final void mPLUS() throws RecognitionException {
        try {
            int _type = PLUS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:96:5: ( '+' )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:96:7: '+'
            {
            match('+'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "PLUS"

    // $ANTLR start "MINUS"
    public final void mMINUS() throws RecognitionException {
        try {
            int _type = MINUS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:97:6: ( '-' )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:97:8: '-'
            {
            match('-'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "MINUS"

    // $ANTLR start "OPENB"
    public final void mOPENB() throws RecognitionException {
        try {
            int _type = OPENB;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:98:6: ( '[' )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:98:8: '['
            {
            match('['); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "OPENB"

    // $ANTLR start "CLOSEB"
    public final void mCLOSEB() throws RecognitionException {
        try {
            int _type = CLOSEB;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:99:7: ( ']' )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:99:9: ']'
            {
            match(']'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "CLOSEB"

    // $ANTLR start "OPENP"
    public final void mOPENP() throws RecognitionException {
        try {
            int _type = OPENP;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:100:6: ( '(' )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:100:8: '('
            {
            match('('); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "OPENP"

    // $ANTLR start "CLOSEP"
    public final void mCLOSEP() throws RecognitionException {
        try {
            int _type = CLOSEP;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:101:7: ( ')' )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:101:9: ')'
            {
            match(')'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "CLOSEP"

    // $ANTLR start "COMMA"
    public final void mCOMMA() throws RecognitionException {
        try {
            int _type = COMMA;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:102:6: ( ',' )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:102:8: ','
            {
            match(','); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "COMMA"

    // $ANTLR start "COLON"
    public final void mCOLON() throws RecognitionException {
        try {
            int _type = COLON;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:103:6: ( ':' )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:103:9: ':'
            {
            match(':'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "COLON"

    // $ANTLR start "DOUBLE"
    public final void mDOUBLE() throws RecognitionException {
        try {
            int _type = DOUBLE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:105:7: ( ( '0' .. '9' )+ '.' ( '0' .. '9' )* ( Exponent )? | '.' ( '0' .. '9' )+ ( Exponent )? | ( '0' .. '9' )+ ( Exponent )? )
            int alt11=3;
            alt11 = dfa11.predict(input);
            switch (alt11) {
                case 1 :
                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:105:11: ( '0' .. '9' )+ '.' ( '0' .. '9' )* ( Exponent )?
                    {
                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:105:11: ( '0' .. '9' )+
                    int cnt4=0;
                    loop4:
                    do {
                        int alt4=2;
                        int LA4_0 = input.LA(1);

                        if ( ((LA4_0>='0' && LA4_0<='9')) ) {
                            alt4=1;
                        }


                        switch (alt4) {
                    	case 1 :
                    	    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:105:12: '0' .. '9'
                    	    {
                    	    matchRange('0','9'); 

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt4 >= 1 ) break loop4;
                                EarlyExitException eee =
                                    new EarlyExitException(4, input);
                                throw eee;
                        }
                        cnt4++;
                    } while (true);

                    match('.'); 
                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:105:27: ( '0' .. '9' )*
                    loop5:
                    do {
                        int alt5=2;
                        int LA5_0 = input.LA(1);

                        if ( ((LA5_0>='0' && LA5_0<='9')) ) {
                            alt5=1;
                        }


                        switch (alt5) {
                    	case 1 :
                    	    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:105:28: '0' .. '9'
                    	    {
                    	    matchRange('0','9'); 

                    	    }
                    	    break;

                    	default :
                    	    break loop5;
                        }
                    } while (true);

                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:105:39: ( Exponent )?
                    int alt6=2;
                    int LA6_0 = input.LA(1);

                    if ( (LA6_0=='E'||LA6_0=='e') ) {
                        alt6=1;
                    }
                    switch (alt6) {
                        case 1 :
                            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:105:39: Exponent
                            {
                            mExponent(); 

                            }
                            break;

                    }


                    }
                    break;
                case 2 :
                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:106:9: '.' ( '0' .. '9' )+ ( Exponent )?
                    {
                    match('.'); 
                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:106:13: ( '0' .. '9' )+
                    int cnt7=0;
                    loop7:
                    do {
                        int alt7=2;
                        int LA7_0 = input.LA(1);

                        if ( ((LA7_0>='0' && LA7_0<='9')) ) {
                            alt7=1;
                        }


                        switch (alt7) {
                    	case 1 :
                    	    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:106:14: '0' .. '9'
                    	    {
                    	    matchRange('0','9'); 

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt7 >= 1 ) break loop7;
                                EarlyExitException eee =
                                    new EarlyExitException(7, input);
                                throw eee;
                        }
                        cnt7++;
                    } while (true);

                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:106:25: ( Exponent )?
                    int alt8=2;
                    int LA8_0 = input.LA(1);

                    if ( (LA8_0=='E'||LA8_0=='e') ) {
                        alt8=1;
                    }
                    switch (alt8) {
                        case 1 :
                            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:106:25: Exponent
                            {
                            mExponent(); 

                            }
                            break;

                    }


                    }
                    break;
                case 3 :
                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:107:9: ( '0' .. '9' )+ ( Exponent )?
                    {
                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:107:9: ( '0' .. '9' )+
                    int cnt9=0;
                    loop9:
                    do {
                        int alt9=2;
                        int LA9_0 = input.LA(1);

                        if ( ((LA9_0>='0' && LA9_0<='9')) ) {
                            alt9=1;
                        }


                        switch (alt9) {
                    	case 1 :
                    	    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:107:10: '0' .. '9'
                    	    {
                    	    matchRange('0','9'); 

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt9 >= 1 ) break loop9;
                                EarlyExitException eee =
                                    new EarlyExitException(9, input);
                                throw eee;
                        }
                        cnt9++;
                    } while (true);

                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:107:21: ( Exponent )?
                    int alt10=2;
                    int LA10_0 = input.LA(1);

                    if ( (LA10_0=='E'||LA10_0=='e') ) {
                        alt10=1;
                    }
                    switch (alt10) {
                        case 1 :
                            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:107:21: Exponent
                            {
                            mExponent(); 

                            }
                            break;

                    }


                    }
                    break;

            }
            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "DOUBLE"

    // $ANTLR start "Exponent"
    public final void mExponent() throws RecognitionException {
        try {
            int _type = Exponent;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:109:10: ( ( 'e' | 'E' ) ( '+' | '-' )? ( '0' .. '9' )+ )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:109:12: ( 'e' | 'E' ) ( '+' | '-' )? ( '0' .. '9' )+
            {
            if ( input.LA(1)=='E'||input.LA(1)=='e' ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}

            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:109:22: ( '+' | '-' )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0=='+'||LA12_0=='-') ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:
                    {
                    if ( input.LA(1)=='+'||input.LA(1)=='-' ) {
                        input.consume();

                    }
                    else {
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        recover(mse);
                        throw mse;}


                    }
                    break;

            }

            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:109:33: ( '0' .. '9' )+
            int cnt13=0;
            loop13:
            do {
                int alt13=2;
                int LA13_0 = input.LA(1);

                if ( ((LA13_0>='0' && LA13_0<='9')) ) {
                    alt13=1;
                }


                switch (alt13) {
            	case 1 :
            	    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:109:34: '0' .. '9'
            	    {
            	    matchRange('0','9'); 

            	    }
            	    break;

            	default :
            	    if ( cnt13 >= 1 ) break loop13;
                        EarlyExitException eee =
                            new EarlyExitException(13, input);
                        throw eee;
                }
                cnt13++;
            } while (true);


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "Exponent"

    public void mTokens() throws RecognitionException {
        // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:1:8: ( ID | NEWLINE | WS | MULT | DIV | ASSIGN | PLUS | MINUS | OPENB | CLOSEB | OPENP | CLOSEP | COMMA | COLON | DOUBLE | Exponent )
        int alt14=16;
        alt14 = dfa14.predict(input);
        switch (alt14) {
            case 1 :
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:1:10: ID
                {
                mID(); 

                }
                break;
            case 2 :
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:1:13: NEWLINE
                {
                mNEWLINE(); 

                }
                break;
            case 3 :
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:1:21: WS
                {
                mWS(); 

                }
                break;
            case 4 :
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:1:24: MULT
                {
                mMULT(); 

                }
                break;
            case 5 :
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:1:29: DIV
                {
                mDIV(); 

                }
                break;
            case 6 :
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:1:33: ASSIGN
                {
                mASSIGN(); 

                }
                break;
            case 7 :
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:1:40: PLUS
                {
                mPLUS(); 

                }
                break;
            case 8 :
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:1:45: MINUS
                {
                mMINUS(); 

                }
                break;
            case 9 :
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:1:51: OPENB
                {
                mOPENB(); 

                }
                break;
            case 10 :
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:1:57: CLOSEB
                {
                mCLOSEB(); 

                }
                break;
            case 11 :
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:1:64: OPENP
                {
                mOPENP(); 

                }
                break;
            case 12 :
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:1:70: CLOSEP
                {
                mCLOSEP(); 

                }
                break;
            case 13 :
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:1:77: COMMA
                {
                mCOMMA(); 

                }
                break;
            case 14 :
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:1:83: COLON
                {
                mCOLON(); 

                }
                break;
            case 15 :
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:1:89: DOUBLE
                {
                mDOUBLE(); 

                }
                break;
            case 16 :
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withColon.g:1:96: Exponent
                {
                mExponent(); 

                }
                break;

        }

    }


    protected DFA11 dfa11 = new DFA11(this);
    protected DFA14 dfa14 = new DFA14(this);
    static final String DFA11_eotS =
        "\1\uffff\1\4\3\uffff";
    static final String DFA11_eofS =
        "\5\uffff";
    static final String DFA11_minS =
        "\2\56\3\uffff";
    static final String DFA11_maxS =
        "\2\71\3\uffff";
    static final String DFA11_acceptS =
        "\2\uffff\1\2\1\1\1\3";
    static final String DFA11_specialS =
        "\5\uffff}>";
    static final String[] DFA11_transitionS = {
            "\1\2\1\uffff\12\1",
            "\1\3\1\uffff\12\1",
            "",
            "",
            ""
    };

    static final short[] DFA11_eot = DFA.unpackEncodedString(DFA11_eotS);
    static final short[] DFA11_eof = DFA.unpackEncodedString(DFA11_eofS);
    static final char[] DFA11_min = DFA.unpackEncodedStringToUnsignedChars(DFA11_minS);
    static final char[] DFA11_max = DFA.unpackEncodedStringToUnsignedChars(DFA11_maxS);
    static final short[] DFA11_accept = DFA.unpackEncodedString(DFA11_acceptS);
    static final short[] DFA11_special = DFA.unpackEncodedString(DFA11_specialS);
    static final short[][] DFA11_transition;

    static {
        int numStates = DFA11_transitionS.length;
        DFA11_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA11_transition[i] = DFA.unpackEncodedString(DFA11_transitionS[i]);
        }
    }

    class DFA11 extends DFA {

        public DFA11(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 11;
            this.eot = DFA11_eot;
            this.eof = DFA11_eof;
            this.min = DFA11_min;
            this.max = DFA11_max;
            this.accept = DFA11_accept;
            this.special = DFA11_special;
            this.transition = DFA11_transition;
        }
        public String getDescription() {
            return "105:1: DOUBLE : ( ( '0' .. '9' )+ '.' ( '0' .. '9' )* ( Exponent )? | '.' ( '0' .. '9' )+ ( Exponent )? | ( '0' .. '9' )+ ( Exponent )? );";
        }
    }
    static final String DFA14_eotS =
        "\1\uffff\1\20\20\uffff";
    static final String DFA14_eofS =
        "\22\uffff";
    static final String DFA14_minS =
        "\1\11\1\53\20\uffff";
    static final String DFA14_maxS =
        "\1\172\1\71\20\uffff";
    static final String DFA14_acceptS =
        "\2\uffff\1\2\1\3\1\4\1\5\1\6\1\7\1\10\1\11\1\12\1\13\1\14\1\15"+
        "\1\16\1\17\1\1\1\20";
    static final String DFA14_specialS =
        "\22\uffff}>";
    static final String[] DFA14_transitionS = {
            "\1\3\1\2\2\uffff\1\2\22\uffff\1\3\7\uffff\1\13\1\14\1\4\1\7"+
            "\1\15\1\10\1\17\1\5\12\17\1\16\2\uffff\1\6\3\uffff\4\20\1\1"+
            "\25\20\1\11\1\uffff\1\12\3\uffff\4\20\1\1\25\20",
            "\1\21\1\uffff\1\21\2\uffff\12\21",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA14_eot = DFA.unpackEncodedString(DFA14_eotS);
    static final short[] DFA14_eof = DFA.unpackEncodedString(DFA14_eofS);
    static final char[] DFA14_min = DFA.unpackEncodedStringToUnsignedChars(DFA14_minS);
    static final char[] DFA14_max = DFA.unpackEncodedStringToUnsignedChars(DFA14_maxS);
    static final short[] DFA14_accept = DFA.unpackEncodedString(DFA14_acceptS);
    static final short[] DFA14_special = DFA.unpackEncodedString(DFA14_specialS);
    static final short[][] DFA14_transition;

    static {
        int numStates = DFA14_transitionS.length;
        DFA14_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA14_transition[i] = DFA.unpackEncodedString(DFA14_transitionS[i]);
        }
    }

    class DFA14 extends DFA {

        public DFA14(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 14;
            this.eot = DFA14_eot;
            this.eof = DFA14_eof;
            this.min = DFA14_min;
            this.max = DFA14_max;
            this.accept = DFA14_accept;
            this.special = DFA14_special;
            this.transition = DFA14_transition;
        }
        public String getDescription() {
            return "1:1: Tokens : ( ID | NEWLINE | WS | MULT | DIV | ASSIGN | PLUS | MINUS | OPENB | CLOSEB | OPENP | CLOSEP | COMMA | COLON | DOUBLE | Exponent );";
        }
    }
 

}