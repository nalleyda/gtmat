// $ANTLR 3.3 Nov 30, 2010 12:45:30 C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g 2011-05-14 10:45:49
package parser;

import interpreter.*;
import jmatrix.*;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;


import org.antlr.runtime.tree.*;

public class Standalone_A_Parser extends Parser {

    public static final String[] tokenNames = new String[]{
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "STATLIST", "NEWLINE", "ID", "ASSIGN", "PLUS", "MINUS", "MULT", "DIV", "INT", "DOUBLE", "OPENP", "CLOSEP", "WS", "Exponent"
    };
    public static final int EOF = -1;
    public static final int STATLIST = 4;
    public static final int NEWLINE = 5;
    public static final int ID = 6;
    public static final int ASSIGN = 7;
    public static final int PLUS = 8;
    public static final int MINUS = 9;
    public static final int MULT = 10;
    public static final int DIV = 11;
    public static final int INT = 12;
    public static final int DOUBLE = 13;
    public static final int OPENP = 14;
    public static final int CLOSEP = 15;
    public static final int WS = 16;
    public static final int Exponent = 17;

    // delegates
    // delegators
    public Standalone_A_Parser(TokenStream input) {
        this(input, new RecognizerSharedState());
    }

    public Standalone_A_Parser(TokenStream input, RecognizerSharedState state) {
        super(input, state);

    }
    protected TreeAdaptor adaptor = new CommonTreeAdaptor();

    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = adaptor;
    }

    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }

    public String[] getTokenNames() {
        return Standalone_A_Parser.tokenNames;
    }

    public String getGrammarFileName() {
        return "C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g";
    }

    public static class prog_return extends ParserRuleReturnScope {

        CommonTree tree;

        public Object getTree() {
            return tree;
        }
    };

    // $ANTLR start "prog"
    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g:26:1: prog : ( stat )+ -> ^( STATLIST ( stat )+ ) ;
    public final Standalone_A_Parser.prog_return prog() throws RecognitionException {
        Standalone_A_Parser.prog_return retval = new Standalone_A_Parser.prog_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Standalone_A_Parser.stat_return stat1 = null;


        RewriteRuleSubtreeStream stream_stat = new RewriteRuleSubtreeStream(adaptor, "rule stat");
        try {
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g:26:5: ( ( stat )+ -> ^( STATLIST ( stat )+ ) )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g:26:9: ( stat )+
            {
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g:26:9: ( stat )+
                int cnt1 = 0;
                loop1:
                do {
                    int alt1 = 2;
                    int LA1_0 = input.LA(1);

                    if (((LA1_0 >= NEWLINE && LA1_0 <= ID) || (LA1_0 >= INT && LA1_0 <= OPENP))) {
                        alt1 = 1;
                    }


                    switch (alt1) {
                        case 1: // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g:26:11: stat
                        {
                            pushFollow(FOLLOW_stat_in_prog69);
                            stat1 = stat();

                            state._fsp--;

                            stream_stat.add(stat1.getTree());

                        }
                        break;

                        default:
                            if (cnt1 >= 1) {
                                break loop1;
                            }
                            EarlyExitException eee =
                                    new EarlyExitException(1, input);
                            throw eee;
                    }
                    cnt1++;
                } while (true);



                // AST REWRITE
                // elements: stat
                // token labels:
                // rule labels: retval
                // token list labels:
                // rule list labels:
                // wildcard labels:
                retval.tree = root_0;
                RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "rule retval", retval != null ? retval.tree : null);

                root_0 = (CommonTree) adaptor.nil();
                // 26:19: -> ^( STATLIST ( stat )+ )
                {
                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g:26:22: ^( STATLIST ( stat )+ )
                    {
                        CommonTree root_1 = (CommonTree) adaptor.nil();
                        root_1 = (CommonTree) adaptor.becomeRoot((CommonTree) adaptor.create(STATLIST, "STATLIST"), root_1);

                        if (!(stream_stat.hasNext())) {
                            throw new RewriteEarlyExitException();
                        }
                        while (stream_stat.hasNext()) {
                            adaptor.addChild(root_1, stream_stat.nextTree());

                        }
                        stream_stat.reset();

                        adaptor.addChild(root_0, root_1);
                    }

                }

                retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree) adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        } catch (RecognitionException re) {
            reportError(re);
            recover(input, re);
            retval.tree = (CommonTree) adaptor.errorNode(input, retval.start, input.LT(-1), re);

        } finally {
        }
        return retval;
    }
    // $ANTLR end "prog"

    public static class stat_return extends ParserRuleReturnScope {

        CommonTree tree;

        public Object getTree() {
            return tree;
        }
    };

    // $ANTLR start "stat"
    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g:28:1: stat : ( expr NEWLINE | ID ASSIGN expr NEWLINE | NEWLINE );
    public final Standalone_A_Parser.stat_return stat() throws RecognitionException {
        Standalone_A_Parser.stat_return retval = new Standalone_A_Parser.stat_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token NEWLINE3 = null;
        Token ID4 = null;
        Token ASSIGN5 = null;
        Token NEWLINE7 = null;
        Token NEWLINE8 = null;
        Standalone_A_Parser.expr_return expr2 = null;

        Standalone_A_Parser.expr_return expr6 = null;


        CommonTree NEWLINE3_tree = null;
        CommonTree ID4_tree = null;
        CommonTree ASSIGN5_tree = null;
        CommonTree NEWLINE7_tree = null;
        CommonTree NEWLINE8_tree = null;

        try {
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g:28:5: ( expr NEWLINE | ID ASSIGN expr NEWLINE | NEWLINE )
            int alt2 = 3;
            switch (input.LA(1)) {
                case INT:
                case DOUBLE:
                case OPENP: {
                    alt2 = 1;
                }
                break;
                case ID: {
                    int LA2_2 = input.LA(2);

                    if ((LA2_2 == NEWLINE || (LA2_2 >= PLUS && LA2_2 <= DIV) || LA2_2 == OPENP)) {
                        alt2 = 1;
                    } else if ((LA2_2 == ASSIGN)) {
                        alt2 = 2;
                    } else {
                        NoViableAltException nvae =
                                new NoViableAltException("", 2, 2, input);

                        throw nvae;
                    }
                }
                break;
                case NEWLINE: {
                    alt2 = 3;
                }
                break;
                default:
                    NoViableAltException nvae =
                            new NoViableAltException("", 2, 0, input);

                    throw nvae;
            }

            switch (alt2) {
                case 1: // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g:28:9: expr NEWLINE
                {
                    root_0 = (CommonTree) adaptor.nil();

                    pushFollow(FOLLOW_expr_in_stat93);
                    expr2 = expr();

                    state._fsp--;

                    adaptor.addChild(root_0, expr2.getTree());
                    NEWLINE3 = (Token) match(input, NEWLINE, FOLLOW_NEWLINE_in_stat95);
                    NEWLINE3_tree = (CommonTree) adaptor.create(NEWLINE3);
                    adaptor.addChild(root_0, NEWLINE3_tree);

                    Interpreter.displayString("ans = " + (expr2 != null ? expr2.value : null));
                    Interpreter.putValue("ans", new Matrix((expr2 != null ? expr2.value : null)));


                }
                break;
                case 2: // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g:31:9: ID ASSIGN expr NEWLINE
                {
                    root_0 = (CommonTree) adaptor.nil();

                    ID4 = (Token) match(input, ID, FOLLOW_ID_in_stat108);
                    ID4_tree = (CommonTree) adaptor.create(ID4);
                    adaptor.addChild(root_0, ID4_tree);

                    ASSIGN5 = (Token) match(input, ASSIGN, FOLLOW_ASSIGN_in_stat110);
                    ASSIGN5_tree = (CommonTree) adaptor.create(ASSIGN5);
                    adaptor.addChild(root_0, ASSIGN5_tree);

                    pushFollow(FOLLOW_expr_in_stat112);
                    expr6 = expr();

                    state._fsp--;

                    adaptor.addChild(root_0, expr6.getTree());
                    NEWLINE7 = (Token) match(input, NEWLINE, FOLLOW_NEWLINE_in_stat115);
                    NEWLINE7_tree = (CommonTree) adaptor.create(NEWLINE7);
                    adaptor.addChild(root_0, NEWLINE7_tree);

                    Interpreter.putValue((ID4 != null ? ID4.getText() : null), new Matrix((expr6 != null ? expr6.value : null)));
                    Interpreter.displayString((ID4 != null ? ID4.getText() : null) + " = " + (expr6 != null ? expr6.value : null));

                }
                break;
                case 3: // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g:33:9: NEWLINE
                {
                    root_0 = (CommonTree) adaptor.nil();

                    NEWLINE8 = (Token) match(input, NEWLINE, FOLLOW_NEWLINE_in_stat127);
                    NEWLINE8_tree = (CommonTree) adaptor.create(NEWLINE8);
                    adaptor.addChild(root_0, NEWLINE8_tree);


                }
                break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (CommonTree) adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        } catch (RecognitionException re) {
            reportError(re);
            recover(input, re);
            retval.tree = (CommonTree) adaptor.errorNode(input, retval.start, input.LT(-1), re);

        } finally {
        }
        return retval;
    }
    // $ANTLR end "stat"

    public static class expr_return extends ParserRuleReturnScope {

        public Matrix value;
        CommonTree tree;

        public Object getTree() {
            return tree;
        }
    };

    // $ANTLR start "expr"
    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g:36:1: expr returns [Matrix value] : e= multExpr ( PLUS e= multExpr | MINUS e= multExpr )* ;
    public final Standalone_A_Parser.expr_return expr() throws RecognitionException {
        Standalone_A_Parser.expr_return retval = new Standalone_A_Parser.expr_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token PLUS9 = null;
        Token MINUS10 = null;
        Standalone_A_Parser.multExpr_return e = null;


        CommonTree PLUS9_tree = null;
        CommonTree MINUS10_tree = null;

        try {
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g:37:2: (e= multExpr ( PLUS e= multExpr | MINUS e= multExpr )* )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g:37:4: e= multExpr ( PLUS e= multExpr | MINUS e= multExpr )*
            {
                root_0 = (CommonTree) adaptor.nil();

                pushFollow(FOLLOW_multExpr_in_expr150);
                e = multExpr();

                state._fsp--;

                adaptor.addChild(root_0, e.getTree());
                retval.value = (e != null ? e.value : null);
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g:38:3: ( PLUS e= multExpr | MINUS e= multExpr )*
                loop3:
                do {
                    int alt3 = 3;
                    int LA3_0 = input.LA(1);

                    if ((LA3_0 == PLUS)) {
                        alt3 = 1;
                    } else if ((LA3_0 == MINUS)) {
                        alt3 = 2;
                    }


                    switch (alt3) {
                        case 1: // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g:38:5: PLUS e= multExpr
                        {
                            PLUS9 = (Token) match(input, PLUS, FOLLOW_PLUS_in_expr158);
                            PLUS9_tree = (CommonTree) adaptor.create(PLUS9);
                            adaptor.addChild(root_0, PLUS9_tree);

                            pushFollow(FOLLOW_multExpr_in_expr162);
                            e = multExpr();

                            state._fsp--;

                            adaptor.addChild(root_0, e.getTree());
                            retval.value = retval.value.add((e != null ? e.value : null));

                        }
                        break;
                        case 2: // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g:39:5: MINUS e= multExpr
                        {
                            MINUS10 = (Token) match(input, MINUS, FOLLOW_MINUS_in_expr170);
                            MINUS10_tree = (CommonTree) adaptor.create(MINUS10);
                            adaptor.addChild(root_0, MINUS10_tree);

                            pushFollow(FOLLOW_multExpr_in_expr174);
                            e = multExpr();

                            state._fsp--;

                            adaptor.addChild(root_0, e.getTree());
                            retval.value = retval.value.sub((e != null ? e.value : null));

                        }
                        break;

                        default:
                            break loop3;
                    }
                } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree) adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        } catch (RecognitionException re) {
            reportError(re);
            recover(input, re);
            retval.tree = (CommonTree) adaptor.errorNode(input, retval.start, input.LT(-1), re);

        } finally {
        }
        return retval;
    }
    // $ANTLR end "expr"

    public static class multExpr_return extends ParserRuleReturnScope {

        public Matrix value;
        CommonTree tree;

        public Object getTree() {
            return tree;
        }
    };

    // $ANTLR start "multExpr"
    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g:43:1: multExpr returns [Matrix value] : e= atom ( MULT e= atom )* ( DIV e= atom )* ;
    public final Standalone_A_Parser.multExpr_return multExpr() throws RecognitionException {
        Standalone_A_Parser.multExpr_return retval = new Standalone_A_Parser.multExpr_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token MULT11 = null;
        Token DIV12 = null;
        Standalone_A_Parser.atom_return e = null;


        CommonTree MULT11_tree = null;
        CommonTree DIV12_tree = null;

        try {
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g:44:5: (e= atom ( MULT e= atom )* ( DIV e= atom )* )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g:44:9: e= atom ( MULT e= atom )* ( DIV e= atom )*
            {
                root_0 = (CommonTree) adaptor.nil();

                pushFollow(FOLLOW_atom_in_multExpr207);
                e = atom();

                state._fsp--;

                adaptor.addChild(root_0, e.getTree());
                retval.value = (e != null ? e.value : null);
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g:45:9: ( MULT e= atom )*
                loop4:
                do {
                    int alt4 = 2;
                    int LA4_0 = input.LA(1);

                    if ((LA4_0 == MULT)) {
                        alt4 = 1;
                    }


                    switch (alt4) {
                        case 1: // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g:45:10: MULT e= atom
                        {
                            MULT11 = (Token) match(input, MULT, FOLLOW_MULT_in_multExpr220);
                            MULT11_tree = (CommonTree) adaptor.create(MULT11);
                            adaptor.addChild(root_0, MULT11_tree);

                            pushFollow(FOLLOW_atom_in_multExpr224);
                            e = atom();

                            state._fsp--;

                            adaptor.addChild(root_0, e.getTree());
                            retval.value = retval.value.mult((e != null ? e.value : null));

                        }
                        break;

                        default:
                            break loop4;
                    }
                } while (true);

                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g:46:9: ( DIV e= atom )*
                loop5:
                do {
                    int alt5 = 2;
                    int LA5_0 = input.LA(1);

                    if ((LA5_0 == DIV)) {
                        alt5 = 1;
                    }


                    switch (alt5) {
                        case 1: // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g:46:10: DIV e= atom
                        {
                            DIV12 = (Token) match(input, DIV, FOLLOW_DIV_in_multExpr241);
                            DIV12_tree = (CommonTree) adaptor.create(DIV12);
                            adaptor.addChild(root_0, DIV12_tree);

                            pushFollow(FOLLOW_atom_in_multExpr245);
                            e = atom();

                            state._fsp--;

                            adaptor.addChild(root_0, e.getTree());
                            retval.value = retval.value.div((e != null ? e.value : null));

                        }
                        break;

                        default:
                            break loop5;
                    }
                } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree) adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        } catch (RecognitionException re) {
            reportError(re);
            recover(input, re);
            retval.tree = (CommonTree) adaptor.errorNode(input, retval.start, input.LT(-1), re);

        } finally {
        }
        return retval;
    }
    // $ANTLR end "multExpr"

    public static class atom_return extends ParserRuleReturnScope {

        public Matrix value;
        CommonTree tree;

        public Object getTree() {
            return tree;
        }
    };

    // $ANTLR start "atom"
    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g:50:1: atom returns [Matrix value] : ( INT | DOUBLE | ID | '(' expr ')' | ID OPENP expr CLOSEP );
    public final Standalone_A_Parser.atom_return atom() throws RecognitionException {
        Standalone_A_Parser.atom_return retval = new Standalone_A_Parser.atom_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token INT13 = null;
        Token DOUBLE14 = null;
        Token ID15 = null;
        Token char_literal16 = null;
        Token char_literal18 = null;
        Token ID19 = null;
        Token OPENP20 = null;
        Token CLOSEP22 = null;
        Standalone_A_Parser.expr_return expr17 = null;

        Standalone_A_Parser.expr_return expr21 = null;


        CommonTree INT13_tree = null;
        CommonTree DOUBLE14_tree = null;
        CommonTree ID15_tree = null;
        CommonTree char_literal16_tree = null;
        CommonTree char_literal18_tree = null;
        CommonTree ID19_tree = null;
        CommonTree OPENP20_tree = null;
        CommonTree CLOSEP22_tree = null;

        try {
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g:51:2: ( INT | DOUBLE | ID | '(' expr ')' | ID OPENP expr CLOSEP )
            int alt6 = 5;
            switch (input.LA(1)) {
                case INT: {
                    alt6 = 1;
                }
                break;
                case DOUBLE: {
                    alt6 = 2;
                }
                break;
                case ID: {
                    int LA6_3 = input.LA(2);

                    if ((LA6_3 == OPENP)) {
                        alt6 = 5;
                    } else if ((LA6_3 == NEWLINE || (LA6_3 >= PLUS && LA6_3 <= DIV) || LA6_3 == CLOSEP)) {
                        alt6 = 3;
                    } else {
                        NoViableAltException nvae =
                                new NoViableAltException("", 6, 3, input);

                        throw nvae;
                    }
                }
                break;
                case OPENP: {
                    alt6 = 4;
                }
                break;
                default:
                    NoViableAltException nvae =
                            new NoViableAltException("", 6, 0, input);

                    throw nvae;
            }

            switch (alt6) {
                case 1: // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g:51:6: INT
                {
                    root_0 = (CommonTree) adaptor.nil();

                    INT13 = (Token) match(input, INT, FOLLOW_INT_in_atom281);
                    INT13_tree = (CommonTree) adaptor.create(INT13);
                    adaptor.addChild(root_0, INT13_tree);

                    retval.value = new Matrix(Double.parseDouble((INT13 != null ? INT13.getText() : null)));

                }
                break;
                case 2: // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g:52:6: DOUBLE
                {
                    root_0 = (CommonTree) adaptor.nil();

                    DOUBLE14 = (Token) match(input, DOUBLE, FOLLOW_DOUBLE_in_atom290);
                    DOUBLE14_tree = (CommonTree) adaptor.create(DOUBLE14);
                    adaptor.addChild(root_0, DOUBLE14_tree);

                    retval.value = new Matrix(Double.parseDouble((DOUBLE14 != null ? DOUBLE14.getText() : null)));

                }
                break;
                case 3: // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g:53:10: ID
                {
                    root_0 = (CommonTree) adaptor.nil();

                    ID15 = (Token) match(input, ID, FOLLOW_ID_in_atom303);
                    ID15_tree = (CommonTree) adaptor.create(ID15);
                    adaptor.addChild(root_0, ID15_tree);


                    retval.value = (Matrix) Interpreter.getValue((ID15 != null ? ID15.getText() : null));
                    if (retval.value == null) {
                        Interpreter.displayError("undefined variable " + (ID15 != null ? ID15.getText() : null));
                    }


                }
                break;
                case 4: // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g:58:9: '(' expr ')'
                {
                    root_0 = (CommonTree) adaptor.nil();

                    char_literal16 = (Token) match(input, OPENP, FOLLOW_OPENP_in_atom315);
                    pushFollow(FOLLOW_expr_in_atom318);
                    expr17 = expr();

                    state._fsp--;

                    adaptor.addChild(root_0, expr17.getTree());
                    char_literal18 = (Token) match(input, CLOSEP, FOLLOW_CLOSEP_in_atom320);
                    retval.value = (expr17 != null ? expr17.value : null);

                }
                break;
                case 5: // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\Standalone_A_.g:59:7: ID OPENP expr CLOSEP
                {
                    root_0 = (CommonTree) adaptor.nil();

                    ID19 = (Token) match(input, ID, FOLLOW_ID_in_atom331);
                    ID19_tree = (CommonTree) adaptor.create(ID19);
                    adaptor.addChild(root_0, ID19_tree);

                    OPENP20 = (Token) match(input, OPENP, FOLLOW_OPENP_in_atom333);
                    OPENP20_tree = (CommonTree) adaptor.create(OPENP20);
                    adaptor.addChild(root_0, OPENP20_tree);

                    pushFollow(FOLLOW_expr_in_atom335);
                    expr21 = expr();

                    state._fsp--;

                    adaptor.addChild(root_0, expr21.getTree());
                    CLOSEP22 = (Token) match(input, CLOSEP, FOLLOW_CLOSEP_in_atom337);
                    CLOSEP22_tree = (CommonTree) adaptor.create(CLOSEP22);
                    adaptor.addChild(root_0, CLOSEP22_tree);


                    retval.value = (Matrix) Interpreter.call((ID19 != null ? ID19.getText() : null), (expr21 != null ? expr21.value : null));
                    if (retval.value == null) {
                        retval.value = new Matrix();
                    }


                }
                break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (CommonTree) adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        } catch (RecognitionException re) {
            reportError(re);
            recover(input, re);
            retval.tree = (CommonTree) adaptor.errorNode(input, retval.start, input.LT(-1), re);

        } finally {
        }
        return retval;
    }
    // $ANTLR end "atom"
    // Delegated rules
    public static final BitSet FOLLOW_stat_in_prog69 = new BitSet(new long[]{0x0000000000007062L});
    public static final BitSet FOLLOW_expr_in_stat93 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_NEWLINE_in_stat95 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_stat108 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_ASSIGN_in_stat110 = new BitSet(new long[]{0x0000000000007040L});
    public static final BitSet FOLLOW_expr_in_stat112 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_NEWLINE_in_stat115 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NEWLINE_in_stat127 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_multExpr_in_expr150 = new BitSet(new long[]{0x0000000000000302L});
    public static final BitSet FOLLOW_PLUS_in_expr158 = new BitSet(new long[]{0x0000000000007040L});
    public static final BitSet FOLLOW_multExpr_in_expr162 = new BitSet(new long[]{0x0000000000000302L});
    public static final BitSet FOLLOW_MINUS_in_expr170 = new BitSet(new long[]{0x0000000000007040L});
    public static final BitSet FOLLOW_multExpr_in_expr174 = new BitSet(new long[]{0x0000000000000302L});
    public static final BitSet FOLLOW_atom_in_multExpr207 = new BitSet(new long[]{0x0000000000000C02L});
    public static final BitSet FOLLOW_MULT_in_multExpr220 = new BitSet(new long[]{0x0000000000007040L});
    public static final BitSet FOLLOW_atom_in_multExpr224 = new BitSet(new long[]{0x0000000000000C02L});
    public static final BitSet FOLLOW_DIV_in_multExpr241 = new BitSet(new long[]{0x0000000000007040L});
    public static final BitSet FOLLOW_atom_in_multExpr245 = new BitSet(new long[]{0x0000000000000802L});
    public static final BitSet FOLLOW_INT_in_atom281 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DOUBLE_in_atom290 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_atom303 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_OPENP_in_atom315 = new BitSet(new long[]{0x0000000000007040L});
    public static final BitSet FOLLOW_expr_in_atom318 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_CLOSEP_in_atom320 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_atom331 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_OPENP_in_atom333 = new BitSet(new long[]{0x0000000000007040L});
    public static final BitSet FOLLOW_expr_in_atom335 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_CLOSEP_in_atom337 = new BitSet(new long[]{0x0000000000000002L});
}
