/**
 *  Antlr test system
 * @author dsmith
 */
package parser;

import org.antlr.runtime.*;
import org.antlr.runtime.tree.*;
import main.*;
import java.io.*;
import javax.swing.text.*;
import jmatrix.*;
import workspace.*;

public class GTParser {
    private static PrintStream debug = null;
//    private static Grammar_Name_Lexer lex;
    private static withColonLexer lex;

    public static void main(String[] args) throws Exception {

        try {
            debug = new PrintStream(new FileOutputStream("debug.log"));
        } catch (IOException e) {
            System.out.print("Error " + e + " opening debug.log");
        }
        debug.println("debug log opened");

        test();
    }

    public static void test() {
        GTStringStream s = null;
        try {
            s = new GTStringStream("x = 4\n");
            s.append("y = 12\n");
            s.append("y/x\n");
            System.out.println(s);
        } catch(IOException e){};
        process(s);

//        process("src/parser/__Test___input.txt");
    }

    public static void process(String name) {
        // Create an input character stream
        try {
//            lex = new Grammar_Name_Lexer(new ANTLRFileStream(name));
            lex = new withColonLexer(new ANTLRFileStream(name));
        } catch (IOException e) {
            debug.println("didn't open " + name);
        }

        doit(lex);
    }


   public static void process(GTStringStream sstr) {
        // Create an input character stream
        doit(new withColonLexer(sstr));
    }


    private static void doit(withColonLexer lx) {
        CommonTokenStream tokens = new CommonTokenStream(lx);

//        Grammar_Name_Parser g = new Grammar_Name_Parser(tokens, null);
        withColonParser g = new withColonParser(tokens, null);
        try {
            g.prog();
        } catch (RecognitionException e) {
            e.printStackTrace();
        }
    }
}
