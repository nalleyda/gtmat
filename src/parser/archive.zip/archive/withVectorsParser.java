// $ANTLR 3.3 Nov 30, 2010 12:45:30 C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g 2011-05-15 14:59:17

package parser;
import interpreter.*;
import jmatrix.*;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;


import org.antlr.runtime.tree.*;

public class withVectorsParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "STATLIST", "NEWLINE", "ID", "ASSIGN", "PLUS", "MINUS", "MULT", "DIV", "DOUBLE", "OPENP", "CLOSEP", "OPENB", "CLOSEB", "COMMA", "WS", "COLON", "Exponent"
    };
    public static final int EOF=-1;
    public static final int STATLIST=4;
    public static final int NEWLINE=5;
    public static final int ID=6;
    public static final int ASSIGN=7;
    public static final int PLUS=8;
    public static final int MINUS=9;
    public static final int MULT=10;
    public static final int DIV=11;
    public static final int DOUBLE=12;
    public static final int OPENP=13;
    public static final int CLOSEP=14;
    public static final int OPENB=15;
    public static final int CLOSEB=16;
    public static final int COMMA=17;
    public static final int WS=18;
    public static final int COLON=19;
    public static final int Exponent=20;

    // delegates
    // delegators


        public withVectorsParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public withVectorsParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        
    protected TreeAdaptor adaptor = new CommonTreeAdaptor();

    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = adaptor;
    }
    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }

    public String[] getTokenNames() { return withVectorsParser.tokenNames; }
    public String getGrammarFileName() { return "C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g"; }




    public static class prog_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "prog"
    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:24:1: prog : ( stat )+ -> ^( STATLIST ( stat )+ ) ;
    public final withVectorsParser.prog_return prog() throws RecognitionException {
        withVectorsParser.prog_return retval = new withVectorsParser.prog_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        withVectorsParser.stat_return stat1 = null;


        RewriteRuleSubtreeStream stream_stat=new RewriteRuleSubtreeStream(adaptor,"rule stat");
        try {
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:24:5: ( ( stat )+ -> ^( STATLIST ( stat )+ ) )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:24:9: ( stat )+
            {
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:24:9: ( stat )+
            int cnt1=0;
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>=NEWLINE && LA1_0<=ID)||(LA1_0>=DOUBLE && LA1_0<=OPENP)) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:24:11: stat
            	    {
            	    pushFollow(FOLLOW_stat_in_prog69);
            	    stat1=stat();

            	    state._fsp--;

            	    stream_stat.add(stat1.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt1 >= 1 ) break loop1;
                        EarlyExitException eee =
                            new EarlyExitException(1, input);
                        throw eee;
                }
                cnt1++;
            } while (true);



            // AST REWRITE
            // elements: stat
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 24:19: -> ^( STATLIST ( stat )+ )
            {
                // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:24:22: ^( STATLIST ( stat )+ )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(STATLIST, "STATLIST"), root_1);

                if ( !(stream_stat.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_stat.hasNext() ) {
                    adaptor.addChild(root_1, stream_stat.nextTree());

                }
                stream_stat.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "prog"

    public static class stat_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "stat"
    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:26:1: stat : ( expr NEWLINE | ID ASSIGN expr NEWLINE | ID ASSIGN vector NEWLINE | NEWLINE );
    public final withVectorsParser.stat_return stat() throws RecognitionException {
        withVectorsParser.stat_return retval = new withVectorsParser.stat_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token NEWLINE3=null;
        Token ID4=null;
        Token ASSIGN5=null;
        Token NEWLINE7=null;
        Token ID8=null;
        Token ASSIGN9=null;
        Token NEWLINE11=null;
        Token NEWLINE12=null;
        withVectorsParser.expr_return expr2 = null;

        withVectorsParser.expr_return expr6 = null;

        withVectorsParser.vector_return vector10 = null;


        CommonTree NEWLINE3_tree=null;
        CommonTree ID4_tree=null;
        CommonTree ASSIGN5_tree=null;
        CommonTree NEWLINE7_tree=null;
        CommonTree ID8_tree=null;
        CommonTree ASSIGN9_tree=null;
        CommonTree NEWLINE11_tree=null;
        CommonTree NEWLINE12_tree=null;

        try {
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:26:5: ( expr NEWLINE | ID ASSIGN expr NEWLINE | ID ASSIGN vector NEWLINE | NEWLINE )
            int alt2=4;
            switch ( input.LA(1) ) {
            case DOUBLE:
            case OPENP:
                {
                alt2=1;
                }
                break;
            case ID:
                {
                int LA2_2 = input.LA(2);

                if ( (LA2_2==NEWLINE||(LA2_2>=PLUS && LA2_2<=DIV)||LA2_2==OPENP) ) {
                    alt2=1;
                }
                else if ( (LA2_2==ASSIGN) ) {
                    int LA2_4 = input.LA(3);

                    if ( (LA2_4==ID||(LA2_4>=DOUBLE && LA2_4<=OPENP)) ) {
                        alt2=2;
                    }
                    else if ( (LA2_4==OPENB) ) {
                        alt2=3;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 2, 4, input);

                        throw nvae;
                    }
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 2, 2, input);

                    throw nvae;
                }
                }
                break;
            case NEWLINE:
                {
                alt2=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }

            switch (alt2) {
                case 1 :
                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:26:9: expr NEWLINE
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_expr_in_stat93);
                    expr2=expr();

                    state._fsp--;

                    adaptor.addChild(root_0, expr2.getTree());
                    NEWLINE3=(Token)match(input,NEWLINE,FOLLOW_NEWLINE_in_stat95); 
                    NEWLINE3_tree = (CommonTree)adaptor.create(NEWLINE3);
                    adaptor.addChild(root_0, NEWLINE3_tree);

                     Interpreter.displayString("ans = " + (expr2!=null?expr2.value:null)); 
                    			Interpreter.putValue("ans", new Matrix((expr2!=null?expr2.value:null))); 
                    		

                    }
                    break;
                case 2 :
                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:29:9: ID ASSIGN expr NEWLINE
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    ID4=(Token)match(input,ID,FOLLOW_ID_in_stat108); 
                    ID4_tree = (CommonTree)adaptor.create(ID4);
                    adaptor.addChild(root_0, ID4_tree);

                    ASSIGN5=(Token)match(input,ASSIGN,FOLLOW_ASSIGN_in_stat110); 
                    ASSIGN5_tree = (CommonTree)adaptor.create(ASSIGN5);
                    adaptor.addChild(root_0, ASSIGN5_tree);

                    pushFollow(FOLLOW_expr_in_stat112);
                    expr6=expr();

                    state._fsp--;

                    adaptor.addChild(root_0, expr6.getTree());
                    NEWLINE7=(Token)match(input,NEWLINE,FOLLOW_NEWLINE_in_stat115); 
                    NEWLINE7_tree = (CommonTree)adaptor.create(NEWLINE7);
                    adaptor.addChild(root_0, NEWLINE7_tree);

                    Interpreter.putValue( (ID4!=null?ID4.getText():null), new Matrix((expr6!=null?expr6.value:null)));
                                                     Interpreter.displayString((ID4!=null?ID4.getText():null) + " = " + (expr6!=null?expr6.value:null)); 

                    }
                    break;
                case 3 :
                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:31:9: ID ASSIGN vector NEWLINE
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    ID8=(Token)match(input,ID,FOLLOW_ID_in_stat127); 
                    ID8_tree = (CommonTree)adaptor.create(ID8);
                    adaptor.addChild(root_0, ID8_tree);

                    ASSIGN9=(Token)match(input,ASSIGN,FOLLOW_ASSIGN_in_stat129); 
                    ASSIGN9_tree = (CommonTree)adaptor.create(ASSIGN9);
                    adaptor.addChild(root_0, ASSIGN9_tree);

                    pushFollow(FOLLOW_vector_in_stat131);
                    vector10=vector();

                    state._fsp--;

                    adaptor.addChild(root_0, vector10.getTree());
                    NEWLINE11=(Token)match(input,NEWLINE,FOLLOW_NEWLINE_in_stat134); 
                    NEWLINE11_tree = (CommonTree)adaptor.create(NEWLINE11);
                    adaptor.addChild(root_0, NEWLINE11_tree);

                    Interpreter.putValue( (ID8!=null?ID8.getText():null), new Matrix((vector10!=null?vector10.value:null)));
                                                     Interpreter.displayString((ID8!=null?ID8.getText():null) + " = " + (vector10!=null?vector10.value:null)); 

                    }
                    break;
                case 4 :
                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:33:9: NEWLINE
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    NEWLINE12=(Token)match(input,NEWLINE,FOLLOW_NEWLINE_in_stat146); 
                    NEWLINE12_tree = (CommonTree)adaptor.create(NEWLINE12);
                    adaptor.addChild(root_0, NEWLINE12_tree);


                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "stat"

    public static class expr_return extends ParserRuleReturnScope {
        public Matrix value;
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "expr"
    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:36:1: expr returns [Matrix value] : e= multExpr ( PLUS e= multExpr | MINUS e= multExpr )* ;
    public final withVectorsParser.expr_return expr() throws RecognitionException {
        withVectorsParser.expr_return retval = new withVectorsParser.expr_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token PLUS13=null;
        Token MINUS14=null;
        withVectorsParser.multExpr_return e = null;


        CommonTree PLUS13_tree=null;
        CommonTree MINUS14_tree=null;

        try {
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:37:2: (e= multExpr ( PLUS e= multExpr | MINUS e= multExpr )* )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:37:4: e= multExpr ( PLUS e= multExpr | MINUS e= multExpr )*
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_multExpr_in_expr169);
            e=multExpr();

            state._fsp--;

            adaptor.addChild(root_0, e.getTree());
            retval.value = (e!=null?e.value:null);
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:38:3: ( PLUS e= multExpr | MINUS e= multExpr )*
            loop3:
            do {
                int alt3=3;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==PLUS) ) {
                    alt3=1;
                }
                else if ( (LA3_0==MINUS) ) {
                    alt3=2;
                }


                switch (alt3) {
            	case 1 :
            	    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:38:5: PLUS e= multExpr
            	    {
            	    PLUS13=(Token)match(input,PLUS,FOLLOW_PLUS_in_expr177); 
            	    PLUS13_tree = (CommonTree)adaptor.create(PLUS13);
            	    adaptor.addChild(root_0, PLUS13_tree);

            	    pushFollow(FOLLOW_multExpr_in_expr181);
            	    e=multExpr();

            	    state._fsp--;

            	    adaptor.addChild(root_0, e.getTree());
            	    retval.value = retval.value.add((e!=null?e.value:null));

            	    }
            	    break;
            	case 2 :
            	    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:39:5: MINUS e= multExpr
            	    {
            	    MINUS14=(Token)match(input,MINUS,FOLLOW_MINUS_in_expr189); 
            	    MINUS14_tree = (CommonTree)adaptor.create(MINUS14);
            	    adaptor.addChild(root_0, MINUS14_tree);

            	    pushFollow(FOLLOW_multExpr_in_expr193);
            	    e=multExpr();

            	    state._fsp--;

            	    adaptor.addChild(root_0, e.getTree());
            	    retval.value = retval.value.sub((e!=null?e.value:null));

            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "expr"

    public static class multExpr_return extends ParserRuleReturnScope {
        public Matrix value;
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "multExpr"
    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:44:1: multExpr returns [Matrix value] : e= atom ( MULT e= atom )* ( DIV e= atom )* ;
    public final withVectorsParser.multExpr_return multExpr() throws RecognitionException {
        withVectorsParser.multExpr_return retval = new withVectorsParser.multExpr_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token MULT15=null;
        Token DIV16=null;
        withVectorsParser.atom_return e = null;


        CommonTree MULT15_tree=null;
        CommonTree DIV16_tree=null;

        try {
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:45:5: (e= atom ( MULT e= atom )* ( DIV e= atom )* )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:45:9: e= atom ( MULT e= atom )* ( DIV e= atom )*
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_atom_in_multExpr227);
            e=atom();

            state._fsp--;

            adaptor.addChild(root_0, e.getTree());
            retval.value = (e!=null?e.value:null);
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:46:9: ( MULT e= atom )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==MULT) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:46:10: MULT e= atom
            	    {
            	    MULT15=(Token)match(input,MULT,FOLLOW_MULT_in_multExpr240); 
            	    MULT15_tree = (CommonTree)adaptor.create(MULT15);
            	    adaptor.addChild(root_0, MULT15_tree);

            	    pushFollow(FOLLOW_atom_in_multExpr244);
            	    e=atom();

            	    state._fsp--;

            	    adaptor.addChild(root_0, e.getTree());
            	    retval.value = retval.value.mult((e!=null?e.value:null)); 

            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:47:9: ( DIV e= atom )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==DIV) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:47:10: DIV e= atom
            	    {
            	    DIV16=(Token)match(input,DIV,FOLLOW_DIV_in_multExpr261); 
            	    DIV16_tree = (CommonTree)adaptor.create(DIV16);
            	    adaptor.addChild(root_0, DIV16_tree);

            	    pushFollow(FOLLOW_atom_in_multExpr265);
            	    e=atom();

            	    state._fsp--;

            	    adaptor.addChild(root_0, e.getTree());
            	    retval.value = retval.value.div((e!=null?e.value:null)); 

            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "multExpr"

    public static class atom_return extends ParserRuleReturnScope {
        public Matrix value;
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "atom"
    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:51:1: atom returns [Matrix value] : ( DOUBLE | ID | '(' expr ')' | ID OPENP expr CLOSEP );
    public final withVectorsParser.atom_return atom() throws RecognitionException {
        withVectorsParser.atom_return retval = new withVectorsParser.atom_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token DOUBLE17=null;
        Token ID18=null;
        Token char_literal19=null;
        Token char_literal21=null;
        Token ID22=null;
        Token OPENP23=null;
        Token CLOSEP25=null;
        withVectorsParser.expr_return expr20 = null;

        withVectorsParser.expr_return expr24 = null;


        CommonTree DOUBLE17_tree=null;
        CommonTree ID18_tree=null;
        CommonTree char_literal19_tree=null;
        CommonTree char_literal21_tree=null;
        CommonTree ID22_tree=null;
        CommonTree OPENP23_tree=null;
        CommonTree CLOSEP25_tree=null;

        try {
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:52:2: ( DOUBLE | ID | '(' expr ')' | ID OPENP expr CLOSEP )
            int alt6=4;
            switch ( input.LA(1) ) {
            case DOUBLE:
                {
                alt6=1;
                }
                break;
            case ID:
                {
                int LA6_2 = input.LA(2);

                if ( (LA6_2==OPENP) ) {
                    alt6=4;
                }
                else if ( (LA6_2==NEWLINE||(LA6_2>=PLUS && LA6_2<=DIV)||LA6_2==CLOSEP||(LA6_2>=CLOSEB && LA6_2<=COMMA)) ) {
                    alt6=2;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 6, 2, input);

                    throw nvae;
                }
                }
                break;
            case OPENP:
                {
                alt6=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }

            switch (alt6) {
                case 1 :
                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:52:6: DOUBLE
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    DOUBLE17=(Token)match(input,DOUBLE,FOLLOW_DOUBLE_in_atom301); 
                    DOUBLE17_tree = (CommonTree)adaptor.create(DOUBLE17);
                    adaptor.addChild(root_0, DOUBLE17_tree);

                    retval.value = new Matrix(Double.parseDouble((DOUBLE17!=null?DOUBLE17.getText():null)));

                    }
                    break;
                case 2 :
                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:53:10: ID
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    ID18=(Token)match(input,ID,FOLLOW_ID_in_atom314); 
                    ID18_tree = (CommonTree)adaptor.create(ID18);
                    adaptor.addChild(root_0, ID18_tree);


                                 retval.value = (Matrix) Interpreter.getValue((ID18!=null?ID18.getText():null));
                                 if(retval.value == null) {
                                     Interpreter.displayError("undefined variable " + (ID18!=null?ID18.getText():null)); }
                                 

                    }
                    break;
                case 3 :
                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:58:10: '(' expr ')'
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    char_literal19=(Token)match(input,OPENP,FOLLOW_OPENP_in_atom327); 
                    pushFollow(FOLLOW_expr_in_atom330);
                    expr20=expr();

                    state._fsp--;

                    adaptor.addChild(root_0, expr20.getTree());
                    char_literal21=(Token)match(input,CLOSEP,FOLLOW_CLOSEP_in_atom332); 
                    retval.value = (expr20!=null?expr20.value:null);

                    }
                    break;
                case 4 :
                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:59:10: ID OPENP expr CLOSEP
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    ID22=(Token)match(input,ID,FOLLOW_ID_in_atom346); 
                    ID22_tree = (CommonTree)adaptor.create(ID22);
                    adaptor.addChild(root_0, ID22_tree);

                    OPENP23=(Token)match(input,OPENP,FOLLOW_OPENP_in_atom348); 
                    OPENP23_tree = (CommonTree)adaptor.create(OPENP23);
                    adaptor.addChild(root_0, OPENP23_tree);

                    pushFollow(FOLLOW_expr_in_atom350);
                    expr24=expr();

                    state._fsp--;

                    adaptor.addChild(root_0, expr24.getTree());
                    CLOSEP25=(Token)match(input,CLOSEP,FOLLOW_CLOSEP_in_atom352); 
                    CLOSEP25_tree = (CommonTree)adaptor.create(CLOSEP25);
                    adaptor.addChild(root_0, CLOSEP25_tree);


                                 retval.value = (Matrix) Interpreter.call((ID22!=null?ID22.getText():null), (expr24!=null?expr24.value:null));
                                 if(retval.value == null) {
                                 	retval.value = new Matrix();
                                 }
                                

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "atom"

    public static class vector_return extends ParserRuleReturnScope {
        public Matrix value;
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "vector"
    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:73:1: vector returns [Matrix value] : ( OPENB CLOSEB | OPENB elems CLOSEB );
    public final withVectorsParser.vector_return vector() throws RecognitionException {
        withVectorsParser.vector_return retval = new withVectorsParser.vector_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token OPENB26=null;
        Token CLOSEB27=null;
        Token OPENB28=null;
        Token CLOSEB30=null;
        withVectorsParser.elems_return elems29 = null;


        CommonTree OPENB26_tree=null;
        CommonTree CLOSEB27_tree=null;
        CommonTree OPENB28_tree=null;
        CommonTree CLOSEB30_tree=null;

        try {
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:74:2: ( OPENB CLOSEB | OPENB elems CLOSEB )
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==OPENB) ) {
                int LA7_1 = input.LA(2);

                if ( (LA7_1==CLOSEB) ) {
                    alt7=1;
                }
                else if ( (LA7_1==ID||(LA7_1>=DOUBLE && LA7_1<=OPENP)) ) {
                    alt7=2;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 7, 1, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }
            switch (alt7) {
                case 1 :
                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:74:5: OPENB CLOSEB
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    OPENB26=(Token)match(input,OPENB,FOLLOW_OPENB_in_vector383); 
                    OPENB26_tree = (CommonTree)adaptor.create(OPENB26);
                    adaptor.addChild(root_0, OPENB26_tree);

                    CLOSEB27=(Token)match(input,CLOSEB,FOLLOW_CLOSEB_in_vector385); 
                    CLOSEB27_tree = (CommonTree)adaptor.create(CLOSEB27);
                    adaptor.addChild(root_0, CLOSEB27_tree);

                    retval.value = new Matrix();

                    }
                    break;
                case 2 :
                    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:75:5: OPENB elems CLOSEB
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    OPENB28=(Token)match(input,OPENB,FOLLOW_OPENB_in_vector393); 
                    OPENB28_tree = (CommonTree)adaptor.create(OPENB28);
                    adaptor.addChild(root_0, OPENB28_tree);

                    pushFollow(FOLLOW_elems_in_vector395);
                    elems29=elems();

                    state._fsp--;

                    adaptor.addChild(root_0, elems29.getTree());
                    CLOSEB30=(Token)match(input,CLOSEB,FOLLOW_CLOSEB_in_vector397); 
                    CLOSEB30_tree = (CommonTree)adaptor.create(CLOSEB30);
                    adaptor.addChild(root_0, CLOSEB30_tree);

                    retval.value = new Matrix((elems29!=null?elems29.value:null));

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "vector"

    public static class elems_return extends ParserRuleReturnScope {
        public Matrix value;
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "elems"
    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:78:1: elems returns [Matrix value] : v= expr ( COMMA v= expr )* ;
    public final withVectorsParser.elems_return elems() throws RecognitionException {
        withVectorsParser.elems_return retval = new withVectorsParser.elems_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token COMMA31=null;
        withVectorsParser.expr_return v = null;


        CommonTree COMMA31_tree=null;

        try {
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:79:2: (v= expr ( COMMA v= expr )* )
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:79:4: v= expr ( COMMA v= expr )*
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_expr_in_elems417);
            v=expr();

            state._fsp--;

            adaptor.addChild(root_0, v.getTree());
            retval.value = new Matrix((v!=null?v.value:null));
            // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:80:4: ( COMMA v= expr )*
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( (LA8_0==COMMA) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // C:\\Users\\dsmith\\Documents\\GT_Mat\\src\\parser\\withVectors.g:80:5: COMMA v= expr
            	    {
            	    COMMA31=(Token)match(input,COMMA,FOLLOW_COMMA_in_elems424); 
            	    COMMA31_tree = (CommonTree)adaptor.create(COMMA31);
            	    adaptor.addChild(root_0, COMMA31_tree);

            	    pushFollow(FOLLOW_expr_in_elems428);
            	    v=expr();

            	    state._fsp--;

            	    adaptor.addChild(root_0, v.getTree());

            	    	        Matrix m = new Matrix((v!=null?v.value:null));
            	    	        retval.value = retval.value.hcat(m);

            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "elems"

    // Delegated rules


 

    public static final BitSet FOLLOW_stat_in_prog69 = new BitSet(new long[]{0x0000000000003062L});
    public static final BitSet FOLLOW_expr_in_stat93 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_NEWLINE_in_stat95 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_stat108 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_ASSIGN_in_stat110 = new BitSet(new long[]{0x0000000000003040L});
    public static final BitSet FOLLOW_expr_in_stat112 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_NEWLINE_in_stat115 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_stat127 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_ASSIGN_in_stat129 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_vector_in_stat131 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_NEWLINE_in_stat134 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NEWLINE_in_stat146 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_multExpr_in_expr169 = new BitSet(new long[]{0x0000000000000302L});
    public static final BitSet FOLLOW_PLUS_in_expr177 = new BitSet(new long[]{0x0000000000003040L});
    public static final BitSet FOLLOW_multExpr_in_expr181 = new BitSet(new long[]{0x0000000000000302L});
    public static final BitSet FOLLOW_MINUS_in_expr189 = new BitSet(new long[]{0x0000000000003040L});
    public static final BitSet FOLLOW_multExpr_in_expr193 = new BitSet(new long[]{0x0000000000000302L});
    public static final BitSet FOLLOW_atom_in_multExpr227 = new BitSet(new long[]{0x0000000000000C02L});
    public static final BitSet FOLLOW_MULT_in_multExpr240 = new BitSet(new long[]{0x0000000000003040L});
    public static final BitSet FOLLOW_atom_in_multExpr244 = new BitSet(new long[]{0x0000000000000C02L});
    public static final BitSet FOLLOW_DIV_in_multExpr261 = new BitSet(new long[]{0x0000000000003040L});
    public static final BitSet FOLLOW_atom_in_multExpr265 = new BitSet(new long[]{0x0000000000000802L});
    public static final BitSet FOLLOW_DOUBLE_in_atom301 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_atom314 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_OPENP_in_atom327 = new BitSet(new long[]{0x0000000000003040L});
    public static final BitSet FOLLOW_expr_in_atom330 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_CLOSEP_in_atom332 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_atom346 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_OPENP_in_atom348 = new BitSet(new long[]{0x0000000000003040L});
    public static final BitSet FOLLOW_expr_in_atom350 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_CLOSEP_in_atom352 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_OPENB_in_vector383 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_CLOSEB_in_vector385 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_OPENB_in_vector393 = new BitSet(new long[]{0x0000000000003040L});
    public static final BitSet FOLLOW_elems_in_vector395 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_CLOSEB_in_vector397 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_expr_in_elems417 = new BitSet(new long[]{0x0000000000020002L});
    public static final BitSet FOLLOW_COMMA_in_elems424 = new BitSet(new long[]{0x0000000000003040L});
    public static final BitSet FOLLOW_expr_in_elems428 = new BitSet(new long[]{0x0000000000020002L});

}